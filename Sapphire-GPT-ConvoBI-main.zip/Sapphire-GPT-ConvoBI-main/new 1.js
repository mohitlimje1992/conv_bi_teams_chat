const { TeamsActivityHandler, CardFactory } = require('botbuilder');
const axios = require('axios');

const username = 'Convobi';
const password = 'CBMA@2024';
const credentials = Buffer.from(`${username}:${password}`).toString('base64');

class TeamsBot extends TeamsActivityHandler {
    constructor() {
        super();

        // Handle members being added to the conversation
        this.onMembersAdded(async (context, next) => {
            const membersAdded = context.activity.membersAdded;
            for (let i = 0; i < membersAdded.length; i++) {
                if (membersAdded[i].id !== context.activity.recipient.id) {
                    // Define the Adaptive Card with quick reply buttons
                    const quickReplyCard = {
                        type: "AdaptiveCard",
                        body: [
                            {
                                type: "TextBlock",
                                text: "FAQ's:",
                                weight: "Bolder",
                                size: "ExtraSmall",
                                wrap: true
                            }
                        ],
                        actions: [
                            {
                                type: "Action.Submit",
                                title: "Sales channel composition in January 2025?",
                                data: { action: "question2" },
                                wrap: true
                            },
                            {
                                type: "Action.Submit",
                                title: "BI sales monthly trend for 2024?",
                                data: { action: "question3" },
                                wrap: true
                            },
                            {
                                type: "Action.Submit",
                                title: "CBM sales in December by week?",
                                data: { action: "question4" },
                                wrap: true
                            }
                        ],
                        $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
                        version: "1.3",
                        innerWidth: "100px"
                    };

                    // Send the quick reply card
                    await context.sendActivity({
                        attachments: [CardFactory.adaptiveCard(quickReplyCard)]
                    });
                }
            }

            // Run the next middleware
            await next();
        });

        // Handle messages from the user
        this.onMessage(async (context, next) => {
            let userMessage = context.activity.text; // Get the user's message

            // Check if the activity has a value (from quick reply buttons)
            if (context.activity.value && context.activity.value.action) {
                switch (context.activity.value.action) {
                    case 'question2':
                        userMessage = "Sales channel composition in January 2025?";
                        break;
                    case 'question3':
                        userMessage = "BI sales monthly trend for 2024?";
                        break;
                    case 'question4':
                        userMessage = "CBM sales in December by week?";
                        break;
                }

                // Send a message mimicking the user's input
                await context.sendActivity({
                    from: { id: context.activity.from.id, name: context.activity.from.name }, // Ensure the message appears as from the user
                    text: userMessage
                });
            }

            try {
                // Call your Python backend API
                const response = await axios.post('https://testappfoursiddh.azurewebsites.net/gpt-request', {
                    prompt: userMessage, // Use 'prompt' instead of 'text'
                }, {
                    headers: {
                        'Authorization': `Basic ${credentials}`
                    }
                });

                // Send the message indicating what was returned
                await context.sendActivity(response.data.message);

                // Check if the response contains multiple adaptive cards
                if (Array.isArray(response.data.response)) {
                    // Iterate over each adaptive card and send it back to Teams
                    for (const adaptiveCard of response.data.response) {
                        if (adaptiveCard.type === 'AdaptiveCard') {
                            await context.sendActivity({
                                attachments: [CardFactory.adaptiveCard(adaptiveCard)]
                            });
                        }
                    }
                } else if (response.data.response.type === 'AdaptiveCard') {
                    // Send the single adaptive card back to Teams
                    const adaptiveCard = response.data.response;
                    await context.sendActivity({
                        attachments: [CardFactory.adaptiveCard(adaptiveCard)]
                    });
                } else {
                    // Send the text response back to Teams
                    await context.sendActivity(response.data.response);
                }

            } catch (error) {
                console.error('Error connecting to Python backend:', error);
                await context.sendActivity('Sorry, there was an error processing your request.');
            }

            // Run the next middleware
            await next();
        });
    }
}

module.exports.TeamsBot = TeamsBot;