sql_examples = [
    {
        "input": "What are the total sales and profit?",
        "query": f"""
-- Calculate the sum of Sales and Profit columns from the dbo.order table.
SELECT
  SUM(Sales) AS "Total Sales",
  SUM(Profit) AS "Total Profit"
FROM dbo.order;
"""
    },
    {
        "input": "Show total sales for the Furniture category.",
        "query": f"""
-- Calculate the total sales specifically for dbo.product in the 'Furniture' category.
-- This requires joining the dbo.order table with the dbo.product table on Product ID.
SELECT
  SUM(o.Sales) AS "Total Furniture Sales"
FROM dbo.order AS o
JOIN dbo.product AS p
  ON o."Product ID" = p."Product ID"
WHERE
  p.Category = 'Furniture';
"""
    },
    {
        "input": "What were the total sales in California in 2014?",
        "query": f"""
-- Calculate the sum of sales for dbo.order placed in the state of California during the year 2014.
-- Filter by State = 'California' and extract the year from the Order Date.
-- Note: Assumes "Order Date" is stored in a format where YEAR extraction is possible (e.g., YYYY-MM-DD or using a YEAR function). Using SUBSTR for demo assuming 'MM/DD/YYYY' or similar fixed format ending in YYYY. Adjust function based on actual DB.
SELECT
  SUM(Sales) AS "Total Sales CA 2014"
FROM dbo.order
WHERE
  State = 'California' AND SUBSTR("Order Date", -4) = '2014'; -- Adjust date extraction based on your SQL dialect and date format
"""
    },
    {
        "input": "Show sales broken down by Region.",
        "query": f"""
-- Group the dbo.order by Region and calculate the sum of Sales for each region.
-- Order the results by total sales in descending order to show the highest sales regions first.
SELECT
  Region,
  SUM(Sales) AS "Total Sales"
FROM dbo.order
GROUP BY
  Region
ORDER BY
  "Total Sales" DESC;
"""
    },
    {
        "input": "Give me the sales breakdown by Region and Customer Segment.",
        "query": f"""
-- Calculate the sum of sales, grouping by both Region and Customer Segment.
-- This shows how sales are distributed across different customer types within each region.
SELECT
  Region,
  "Customer Segment",
  SUM(Sales) AS "Total Sales"
FROM dbo.order
GROUP BY
  Region,
  "Customer Segment"
ORDER BY
  Region,
  "Customer Segment";
"""
    },
    {
        "input": "Which state had the highest profit?",
        "query": f"""
-- Find the state with the maximum total profit.
-- Group dbo.order by State, calculate the sum of Profit for each state.
-- Order the results by profit in descending order and take the top 1 result.
SELECT
  State,
  SUM(Profit) AS "Total Profit"
FROM dbo.order
GROUP BY
  State
ORDER BY
  "Total Profit" DESC
LIMIT 1; -- Use TOP 1 for SQL Server/Access
"""
    },
    {
        "input": "What is the total quantity sold for the 'Chairs' sub-category?",
        "query": f"""
-- Calculate the total number of items sold (Quantity) for dbo.product belonging to the 'Chairs' sub-category.
-- Requires joining dbo.order and dbo.product tables.
SELECT
  SUM(o.Quantity) AS "Total Quantity Chairs"
FROM dbo.order AS o
JOIN dbo.product AS p
  ON o."Product ID" = p."Product ID"
WHERE
  p."Sub-Category" = 'Chairs'; -- Assuming 'Sub-Categ' in the image is 'Sub-Category'
"""
    },
    {
        "input": "List the top 3 product names by total sales.",
        "query": f"""
-- Find the top 3 dbo.product based on their total sales revenue.
-- Join dbo.order and dbo.product tables, group by product name, calculate total sales.
-- Order by sales descending and limit to the top 3.
SELECT
  p."Product Name",
  SUM(o.Sales) AS "Total Sales"
FROM dbo.order AS o
JOIN dbo.product AS p
  ON o."Product ID" = p."Product ID"
GROUP BY
  p."Product Name"
ORDER BY
  "Total Sales" DESC
LIMIT 3; -- Use TOP 3 for SQL Server/Access
"""
    },
    {
        "input": "Show profit for 'Consumer' segment dbo.order shipped via 'Second Class' mode.",
        "query": f"""
-- Calculate the total profit for dbo.order that meet specific criteria:
-- Customer Segment must be 'Consumer'.
-- Ship Mode must be 'Second Class'.
SELECT
  SUM(Profit) AS "Total Profit"
FROM dbo.order
WHERE
  "Customer Segment" = 'Consumer' AND "Ship Mode" = 'Second Class';
"""
    },
    {
        "input": "What is the average discount for dbo.order in the 'West' region?",
        "query": f"""
-- Calculate the average discount applied to line items for dbo.order within the 'West' region.
SELECT
  AVG(Discount) AS "Average Discount West Region"
FROM dbo.order
WHERE
  Region = 'West';
"""
    },
    {
        "input": "Calculate the profit margin for each product category.",
        "query": f"""
-- Calculate Profit Margin (Total Profit / Total Sales) for each product category.
-- Use a Common Table Expression (CTE) for clarity to first aggregate sales and profit per category.
-- Handle potential division by zero if a category has zero sales.
WITH CategoryTotals AS (
  SELECT
    p.Category,
    SUM(o.Sales) AS TotalSales,
    SUM(o.Profit) AS TotalProfit
  FROM dbo.order AS o
  JOIN dbo.product AS p ON o."Product ID" = p."Product ID"
  GROUP BY p.Category
)
SELECT
  Category,
  TotalSales,
  TotalProfit,
  CASE
    WHEN TotalSales = 0 THEN 0 -- Or NULL, depending on desired output for zero sales
    ELSE ROUND((TotalProfit / TotalSales) * 100, 2)
  END AS "Profit Margin (%)"
FROM CategoryTotals
ORDER BY "Profit Margin (%)" DESC;
"""
    },
    {
        "input": "Show the year-over-year sales growth percentage for each region.",
        "query": f"""
-- Calculate the percentage change in total sales from one year to the next, for each region.
-- Requires extracting the year, grouping by year and region, and then using LAG window function to compare with the previous year.
-- Note: Assumes "Order Date" allows year extraction (e.g., SUBSTR used as placeholder). Adjust date logic as needed.
WITH YearlyRegionSales AS (
  SELECT
    SUBSTR("Order Date", -4) AS OrderYear, -- Adjust date extraction based on your SQL dialect and date format
    Region,
    SUM(Sales) AS RegionalSales
  FROM dbo.order
  GROUP BY OrderYear, Region
),
LaggedSales AS (
  SELECT
    OrderYear,
    Region,
    RegionalSales,
    LAG(RegionalSales, 1, 0) OVER (PARTITION BY Region ORDER BY OrderYear ASC) AS PreviousYearSales
  FROM YearlyRegionSales
)
SELECT
  OrderYear,
  Region,
  RegionalSales,
  PreviousYearSales,
  CASE
    WHEN PreviousYearSales = 0 THEN NULL -- Or 0 or 'N/A' if growth calculation isn't meaningful from zero
    ELSE ROUND(((RegionalSales - PreviousYearSales) / PreviousYearSales) * 100, 2)
  END AS "YoY Growth (%)"
FROM LaggedSales
ORDER BY Region, OrderYear;
"""
    },
    {
        "input": "Identify customers whose average order value is above the overall average.",
        "query": f"""
-- Find customers whose average spending per order exceeds the average order value across all customers.
-- Uses two levels of aggregation: first calculate each customer's average, then the overall average, then filter.
WITH Customerdbo.ordertats AS (
  SELECT
    "Customer ID", -- Assuming Customer ID exists uniquely identifies a customer
    "Customer Name",
    SUM(Sales) AS TotalCustomerSales,
    COUNT(DISTINCT "Order ID") AS NumberOfdbo.order
  FROM dbo.order
  GROUP BY "Customer ID", "Customer Name"
),
CustomerAvgOrderValue AS (
  SELECT
    "Customer ID",
    "Customer Name",
    CASE
      WHEN NumberOfdbo.order = 0 THEN 0
      ELSE TotalCustomerSales / NumberOfdbo.order
    END AS AvgOrderValue
  FROM Customerdbo.ordertats
),
OverallAvgOrderValue AS (
  SELECT AVG(AvgOrderValue) AS GlobalAvgValue
  FROM CustomerAvgOrderValue
)
SELECT
  caov."Customer ID",
  caov."Customer Name",
  ROUND(caov.AvgOrderValue, 2) AS "Customer Average Order Value"
FROM CustomerAvgOrderValue AS caov
CROSS JOIN OverallAvgOrderValue AS oaov -- Use CROSS JOIN to compare each customer to the single global average
WHERE caov.AvgOrderValue > oaov.GlobalAvgValue
ORDER BY "Customer Average Order Value" DESC;
"""
    },
    {
        "input": "Rank dbo.product within each sub-category based on total profit.",
        "query": f"""
-- Assign a rank to each product within its sub-category based on its total profit contribution.
-- Uses the RANK() or DENSE_RANK() window function partitioned by sub-category.
WITH ProductProfit AS (
  SELECT
    p."Product Name",
    p."Sub-Category", -- Assuming 'Sub-Categ' is 'Sub-Category'
    SUM(o.Profit) AS TotalProfit
  FROM dbo.order AS o
  JOIN dbo.product AS p ON o."Product ID" = p."Product ID"
  GROUP BY p."Product Name", p."Sub-Category"
)
SELECT
  "Product Name",
  "Sub-Category",
  TotalProfit,
  RANK() OVER (PARTITION BY "Sub-Category" ORDER BY TotalProfit DESC) AS "Profit Rank within Sub-Category"
FROM ProductProfit
ORDER BY "Sub-Category", "Profit Rank within Sub-Category";
"""
    },
    {
        "input": "What percentage of total category sales does each sub-category contribute?",
        "query": f"""
-- For each sub-category, calculate its sales as a percentage of the total sales of its parent category.
-- Uses window functions to calculate both sub-category and category totals efficiently.
WITH SubCategorySales AS (
  SELECT
    p.Category,
    p."Sub-Category", -- Assuming 'Sub-Categ' is 'Sub-Category'
    SUM(o.Sales) AS SubCategoryTotalSales
  FROM dbo.order AS o
  JOIN dbo.product AS p ON o."Product ID" = p."Product ID"
  GROUP BY p.Category, p."Sub-Category"
)
SELECT
  Category,
  "Sub-Category",
  SubCategoryTotalSales,
  SUM(SubCategoryTotalSales) OVER (PARTITION BY Category) AS CategoryTotalSales,
  CASE
    WHEN SUM(SubCategoryTotalSales) OVER (PARTITION BY Category) = 0 THEN 0
    ELSE ROUND((SubCategoryTotalSales / SUM(SubCategoryTotalSales) OVER (PARTITION BY Category)) * 100, 2)
  END AS "Contribution to Category Sales (%)"
FROM SubCategorySales
ORDER BY Category, "Contribution to Category Sales (%)" DESC;
"""
    },
    {
        "input": "List dbo.order containing dbo.product from both 'Furniture' and 'Technology' categories.",
        "query": f"""
-- Identify dbo.order that include at least one item from the Furniture category AND at least one item from the Technology category.
-- Group by Order ID and use conditional counting within the HAVING clause.
SELECT
  o."Order ID"
FROM dbo.order AS o
JOIN dbo.product AS p ON o."Product ID" = p."Product ID"
WHERE p.Category IN ('Furniture', 'Technology') -- Pre-filter for efficiency
GROUP BY o."Order ID"
HAVING
  COUNT(DISTINCT CASE WHEN p.Category = 'Furniture' THEN p."Product ID" END) > 0
  AND
  COUNT(DISTINCT CASE WHEN p.Category = 'Technology' THEN p."Product ID" END) > 0;
-- Optionally join back to dbo.order table if more order details are needed:
-- SELECT o.* FROM dbo.order o WHERE o."Order ID" IN ( <above subquery> );
"""
    },
    {
        "input": "Compare the average profit margin for discounted vs non-discounted items per region.",
        "query": f"""
-- Calculate and compare the average profit margin for items sold with a discount versus those sold without, broken down by region.
-- Profit Margin = Profit / Sales. Use conditional aggregation.
SELECT
    Region,
    -- Average Margin for Non-Discounted Items
    SUM(CASE WHEN Discount = 0 THEN Profit ELSE 0 END) AS Profit_NoDiscount,
    SUM(CASE WHEN Discount = 0 THEN Sales ELSE 0 END) AS Sales_NoDiscount,
    CASE
        WHEN SUM(CASE WHEN Discount = 0 THEN Sales ELSE 0 END) = 0 THEN 0
        ELSE ROUND((SUM(CASE WHEN Discount = 0 THEN Profit ELSE 0 END) / SUM(CASE WHEN Discount = 0 THEN Sales ELSE 0 END)) * 100, 2)
    END AS AvgMargin_NoDiscount_Percent,

    -- Average Margin for Discounted Items
    SUM(CASE WHEN Discount > 0 THEN Profit ELSE 0 END) AS Profit_Discounted,
    SUM(CASE WHEN Discount > 0 THEN Sales ELSE 0 END) AS Sales_Discounted,
     CASE
        WHEN SUM(CASE WHEN Discount > 0 THEN Sales ELSE 0 END) = 0 THEN 0
        ELSE ROUND((SUM(CASE WHEN Discount > 0 THEN Profit ELSE 0 END) / SUM(CASE WHEN Discount > 0 THEN Sales ELSE 0 END)) * 100, 2)
    END AS AvgMargin_Discounted_Percent
FROM dbo.order
GROUP BY Region
ORDER BY Region;

"""
    }
]