from trino.dbapi import connect
from trino.auth import BasicAuthentication
import pandas as pd
conn = connect(
    http_scheme="https",
    host="query.comcast.com",
    port=9443,
    user="ukonth238",
    auth=BasicAuthentication("ukonth238", "Philly18@Philly18@")
)

# conn = connect(
#     http_scheme="https",
#     host="query.comcast.com",
#     port=9443,
#     user="svc-cbmoprod-prod",
#     auth=BasicAuthentication("svc-cbmoprod-prod", "wXUE3734PNM9Pp0HYp3XtLOIeyczHXLQVjM")
# )

cur = conn.cursor()
# query_1="SELECT * FROM minio.dx_dl_comcast_cbmarketing.production_sapphire_2 limit 5"
# query_2="SELECT * FROM minio.dx_dl_comcast_cbmarketing.sapphire_subscribers_table_0123_1224 limit 5"
query_3="SELECT Fiscal_Month, ROUND(SUM(Connects_BI), 1) FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 WHERE UPPER(Division) = 'WEST' AND Fiscal_Month BETWEEN DATE_TRUNC('month', DATE_ADD('month', -11, (SELECT MAX(Fiscal_Month) FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224))) AND (SELECT MAX(Fiscal_Month) FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224) GROUP BY Fiscal_Month"

query_4="SELECT fiscal_month,count(*) as count FROM minio.dx_dl_comcast_cbmarketing.production_demands_table_0123_1224 group by Fiscal_Month"
query_5="SELECT fiscal_month , sum(connects_bi) as BI_Connects FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 group by fiscal_month"
query_6="ALTER TABLE minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 ALTER COLUMN fiscal_year VARCHAR(50)"
query_7="SELECT Fiscal_Month,ROUND(SUM(Connects_BI), 1) AS Number_of_Connects FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 WHERE Fiscal_Month >= (select Fiscal_Month from minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 order by Fiscal_Month desc offset 11 limit 1)  AND UPPER(Division) = 'WEST' GROUP BY Fiscal_Month ORDER BY Fiscal_Month DESC"
query_8 = "select Fiscal_Month from minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 order by Fiscal_Month desc offset 11"

query_9 = "SELECT Fiscal_Month FROM ( SELECT Fiscal_Month, ROW_NUMBER() OVER (ORDER BY Fiscal_Month DESC) AS row_num FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 ) subquery WHERE row_num = 12"
query_10 = "SELECT * FROM minio.dx_dl_comcast_cbmarketing.production_demands_EDD_Leads_Calls_0125 limit 5"
query_11 = "SELECT * FROM minio.dx_dl_comcast_cbmarketing.production_demands_EDD_Sales_0125 limit 5"
query_12 = "SELECT Fiscal_Year, Fiscal_Month,ROUND((SUM(Connects_BI)-SUM(Disconnects_BI)), 1) AS Net_Adds_BI FROM minio.dx_dl_comcast_cbmarketing.production_subscribers_table_0123_1224 WHERE Fiscal_Year = 2024 GROUP BY Fiscal_Year, Fiscal_Month ORDER BY Fiscal_Month DESC"

cur.execute(query_12)
rows = cur.fetchall()
# total bi customers per month
cur.close()
df = pd.DataFrame(rows, columns=[desc[0] for desc in cur.description])
# df.reset_index(drop=True, inplace=True)
print(df)

conn.close()