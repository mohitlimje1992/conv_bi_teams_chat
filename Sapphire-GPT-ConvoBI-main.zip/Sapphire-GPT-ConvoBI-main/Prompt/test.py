
import numpy as np
import pandas as pd
import re
import json
import plotly.graph_objects as go
import copy
import plotly.express as px
from sqlalchemy import create_engine
import urllib.parse
import pyodbc
import os
from openai import AzureOpenAI
driver = "SQL Server" # vs code (local)
# driver = "ODBC Driver 18 for SQL Server"  # github(deployment)
server = 'harmony-db.database.windows.net'
database = 'GPT'
username = 'harmony'
password = 'Comcast@2024'
# conn = pyodbc.connect('Driver={SQL Server};Server='+server+  ';UID='+username+';PWD='+password+';Database='+database)
connection_string = 'mssql+pyodbc:///?odbc_connect={}'.format(urllib.parse.quote_plus('DRIVER={};SERVER={};DATABASE={};UID={};PWD={}'.format(driver, server, database, username, password)))
query_string = """
select distinct([fiscal year]) from sapphiresubs
"""
client = AzureOpenAI(
azure_endpoint = "https://harmony-openai.openai.azure.com/", 
api_key="1247d4f3be3a4d61b2e6c76cb6afdb08",  #1247d4f3be3a4d61b2e6c76cb6afdb08
api_version="2024-08-01-preview")
# client = AzureOpenAI(
# azure_endpoint = "https://harmony-openai-4.openai.azure.com/", 
# api_key = "2279203f336b4ce7bfd07d2bc11abbc6",
# api_version="2024-08-01")

table_dict = {"sapphiresubs": "sapphiresubs"}
import time    
def measure_runtime(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        runtime = end_time - start_time
        print(f"Runtime of {func.__name__}: {runtime} seconds")
        return result
    return wrapper

@measure_runtime
def run_bq_sql(query_string, table_dict):
   
    rep_dict = table_dict
    for key, value in rep_dict.items():
        query_string = query_string.replace(key, value)

    print("----------------run_bq_sql query-------------",query_string)
    df = pd.read_sql_query(query_string, create_engine(connection_string))
    return df
SQL_query = (
        query_string.replace("Query:", "")
        .replace("```", "")
        .replace("SQL", "")
        .replace("sql", "").replace('"""', "")
    )
df_table = run_bq_sql(SQL_query, table_dict)
print(df_table)