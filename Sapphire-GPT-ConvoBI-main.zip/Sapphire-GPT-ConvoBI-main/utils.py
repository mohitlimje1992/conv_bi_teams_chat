import re


def is_valid_sql(input_string):
    sql_keywords = {
        "SELECT",
        "FROM",
        "WHERE",
        "JOIN",
        "ON",
        "GROUP BY",
        "ORDER BY",
        "HAVING",
        "LIMIT",
        "WITH",
        "CREATE",
        "REPLACE",
    }
    sql_pattern = re.compile(r"\b(?:" + "|".join(sql_keywords) + r")\b", re.IGNORECASE)
    if re.search(sql_pattern, input_string):
        if "SELECT" in input_string.upper() and "FROM" in input_string.upper():
            return True

    return False
