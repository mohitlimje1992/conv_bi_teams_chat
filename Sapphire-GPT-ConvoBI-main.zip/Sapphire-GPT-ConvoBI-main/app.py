from dash import Dash, dash_table, dcc, callback, Output, Input, State, callback_context, no_update
from dash import html
from dash.dependencies import Input, Output, ALL
from dash.exceptions import PreventUpdate
from dash.long_callback import DiskcacheLongCallbackManager
from dash_iconify import DashIconify
from dash_mantine_components import theme
from dotenv import load_dotenv
from flask import Flask, send_from_directory,jsonify,request
import base64
from langchain_community.vectorstores import FAISS
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_core.prompts import (FewShotPromptTemplate, PromptTemplate, )
from langchain_openai import AzureOpenAIEmbeddings
from openai import AzureOpenAI
from PIL import Image
from Prompt.few_shot_examples import sql_examples as examples
from Prompt.genai_backend import *
from Prompt.main_prompt_cbma import main_prompt as main_prompt
from reportlab.lib.pagesizes import letter, landscape
from reportlab.pdfgen import canvas
from utils import is_valid_sql
import copy
import dash_auth
import dash_dangerously_set_inner_html
import dash_mantine_components as dmc
import dash_bootstrap_components as dbc
import diskcache
import json
from azure.cosmos import CosmosClient
import numpy as np
import openai
import os
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
# import pygwalker as pyg
import re
import sqlparse
import sys
import time
import vertexai
from datetime import datetime, timedelta
import calendar
import logging
from logger import logger
import random
logger = logger('CBMA_App')

os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://genaiinitiativeopenai.openai.azure.com/"
os.environ["OPENAI_API_KEY"] = "cd2823e85ca04aafa6d7bd0c8cce22d1"
os.environ["OPENAI_API_VERSION"] = "2024-08-01-preview"


client = AzureOpenAI(
azure_endpoint = "https://genaiinitiativeopenai.openai.azure.com/", 
api_key="cd2823e85ca04aafa6d7bd0c8cce22d1",  
api_version="2024-08-01-preview")

vertexai.init()

# from trino.dbapi import connect
# from trino.auth import BasicAuthentication
# conn = connect(
#     http_scheme="https",
#     host="query.comcast.com",
#     port=8443,
#     user="ukonth238",
#     auth=BasicAuthentication("ukonth238", "Philly18@Philly18@")
# )

## Diskcache
cache = diskcache.Cache("./cache")
long_callback_manager = DiskcacheLongCallbackManager(cache)

# TODO: Update the list of table names afterwards.
table_dict = {"dbo.product": "dbo.product","dbo.order":"dbo.order"}
# table_dict = {"minio.dx_dl_comcast_cbmarketing.production_demands_sales_table_0225":"minio.dx_dl_comcast_cbmarketing.production_demands_sales_table_0225"}

external_stylesheets = [dmc.theme.DEFAULT_COLORS]
import os
print("-----**-----**-----*before*------**-------",os.getcwd())

# excel_file_path = "/home/site/repository/data_dictionary.xlsx"

# TODO: Data Dictionary needs updating
excel_file_path = r"data_dictionary.xlsx"
#excel_file_path = "data_dictionary_saphiresubbs.xlsx"
df_dd = pd.read_excel(excel_file_path)
print("-----**-----**-----*after*------**-------",os.getcwd())

import time    
def measure_runtime(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        runtime = end_time - start_time
        print(f"Runtime of {func.__name__}: {runtime} seconds")
        return result
    return wrapper

server = Flask(__name__)
app = Dash(
    __name__,
    external_stylesheets=external_stylesheets,
    title="CBMA - Conversational BI",
    suppress_callback_exceptions=True,
    long_callback_manager=long_callback_manager,server=server, url_base_pathname='/'
)

import dash_auth
import time
USERNAME_PASSWORD_PAIRS = [['Convobi','CBMA@2024']]
auth = dash_auth.BasicAuth(app , USERNAME_PASSWORD_PAIRS)

# Load the FAQ questions from the text file

# with open('faq.txt', 'r') as file:
#     faq_questions = [line.strip() for line in file.readlines()]
faq_questions =[
"BI Sales Trend in Last 6 Months",
"CBM Lines Sold in H2 2024",
"Sales from web leads",
"Sales calls in Northeast Jan25",
"BI Sales vs targets in Q4 2024",
"Revenue from Video Sales in West"
]

server = app.server


customize = html.Div([], id="pygwalker-placeholder")

history = dmc.Stack(children=[], spacing=0, id="history-stack")

dashboard = dmc.Stack(
    [
        dmc.Grid(
            children=[
                dmc.Col(
                    dmc.Center(
                        dmc.Title(
                            "Portfolio Insights",
                            color="#fb4e0b",
                            size="h2",
                            style={"marginBottom": 6},
                        )
                    ),
                    span=9,
                ),
                dmc.Col(
                    dmc.Button(
                        "Download",
                        id="download_button",
                        variant="gradient",
                        gradient={"from": "orange", "to": "red"},
                        leftIcon=DashIconify(icon="material-symbols:download-rounded"),
                    ),
                    span="content",
                    offset=1.5,
                ),
                dmc.Col(
                    dmc.Badge(id="d_badge", children=" "), span="content", offset=10.5
                ),
            ],
        ),
        dmc.Grid([], id="dashboard-grid", style={"marginTop": 5}),
    ]
)

flag = False
thumbsup_button_black_style = {
    "color": "black",
    "position": "absolute",
    "right": "40px",
    "top": "12px",
}
thumbsup_green_button_style = {
    "color": "green",
    "position": "absolute",
    "right": "40px",
    "top": "12px",
}
thumbsdown_black_button_style = {
    "color": "black",
    "position": "absolute",
    "right": "12px",
    "top": "12px",
}
thumbsdown_red_button_style = {
    "color": "red",
    "position": "absolute",
    "right": "12px",
    "top": "12px",
}

tab_style = {
    "background": "rgb(237 232 232)",
    "color": "black",
    "border": "grey",
    "font-size": "20px",
    "font-weight": "bold",
    "align-items": "center",
    "justify-content": "center",
    "border-radius": "4px",
    "padding": "6px",
    "box-shadow": "0 1px 4px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)",
}

tab_selected_style = {
    "background": "rgb(209,243,253)",
    "color": "#000000",
    "font-size": "20px",
    "font-weight": "bold",
    "align-items": "center",
    "justify-content": "center",
    "border-radius": "4px",
    "padding": "6px",
    "border-style": "solid",
    "border-color": "rgb(209,243,253)",
}
footer = dmc.Footer(
    children=dmc.Group(
        children=[dmc.Text("Powered by EXL", size="sm")],
        grow=False,
        style={"width": "100%", "padding-left": 50, "padding-right": 50},
    ),
    fixed=True,
    height=50,
    style={
        "background-color": "#343a40",
        "color": "white",
        "display": "flex",
        "align-items": "center",
    },
)

def format_commas_int(x):
    return "{:,}".format(x)
def format_commas_float(x):
    return "{:,.2f}".format(x)


def convert_float_to_int(df):
    for cols in df.columns:
        try:
            if pd.api.types.is_numeric_dtype(df[cols]):
                if pd.api.types.is_float_dtype(df[cols]):
                    if (df[cols]==df[cols].astype('int64')).all():
                        df[cols]=df[cols].astype('int64')
        except Exception as ee:
            pass
    return df

def check_hello_response(response):
    keywords = ["Hello!", "How can I assist you today with your sales or demand-related queries?"]
    for keyword in keywords:
        if keyword in response:
            return True
    return False



def get_dynamic_dates():
    today = datetime.today()
    # date_string = '2025-03-03 15:21:34'
    # format_string = "%Y-%m-%d %H:%M:%S"
    # today  = datetime.strptime(date_string, format_string)
    
    # Current Week 
    start_of_current_week = today - timedelta(days=today.weekday() + 1)
    current_week_start = str(start_of_current_week.date())

    # Previous Week
    start_of_week = today - timedelta(days=today.weekday() + 8)
    previous_week_start = str(start_of_week.date())
    
    # Previous Fiscal Month
    if today.day >= 22:
        fiscal_month_start = today.replace(day=1)
    else:
        last_month = today.month - 1 if today.month > 1 else 12
        fiscal_month_start = today.replace(month=last_month, day=1)
        if last_month == 12:
            fiscal_month_start = fiscal_month_start.replace(year=today.year - 1)
    fiscal_month_date = fiscal_month_start.date()
    previous_fiscal_month_start = str(fiscal_month_start.date())
    
    # Last Fiscal Quarter
    fiscal_month = fiscal_month_date.month
    if fiscal_month in [1, 2, 3]:
        last_fiscal_quarter_start_date = datetime(today.year - 1, 10, 1)
        last_fiscal_quarter_end_date = datetime(today.year - 1, 12, 1)
    elif fiscal_month in [4, 5, 6]:
        last_fiscal_quarter_start_date = datetime(today.year, 1, 1)
        last_fiscal_quarter_end_date = datetime(today.year, 3, 1)
    elif fiscal_month in [7, 8, 9]:
        last_fiscal_quarter_start_date = datetime(today.year, 4, 1)
        last_fiscal_quarter_end_date = datetime(today.year, 6, 1)
    else:  # fiscal_month in [10, 11, 12]
        last_fiscal_quarter_start_date = datetime(today.year, 7, 1)
        last_fiscal_quarter_end_date = datetime(today.year, 9, 1)
    last_fiscal_quarter = (str(last_fiscal_quarter_start_date.date()), str(last_fiscal_quarter_end_date.date()))
    
    # Last Fiscal half year
    if fiscal_month in [1, 2, 3, 4, 5, 6]:
        start_date_last_half_year = datetime(today.year - 1, 7, 1)
        end_date_last_half_year = datetime(today.year - 1, 12, 1)
    else:  # fiscal_month in [7, 8, 9, 10, 11, 12]
        start_date_last_half_year = datetime(today.year, 1, 1)
        end_date_last_half_year = datetime(today.year, 6, 1)
    last_half_year = (str(start_date_last_half_year.date()), str(end_date_last_half_year.date()))
    
    # Last Fiscal Year
    start_date_last_year = datetime(fiscal_month_start.year - 1, 12, 22)
    end_date_last_year = datetime(fiscal_month_start.year, 12, 21)
    last_year = str(start_date_last_year.year)

    return {
        "current_week":current_week_start,
        "previous_week": previous_week_start,
        "previous_fiscal_month": previous_fiscal_month_start,
        "previous_fiscal_quarter": last_fiscal_quarter,
        "previous_half_year": last_half_year,
        "previous_year": last_year
    }


def blank_fig():
    fig = go.Figure(go.Scatter(x=[], y=[]))
    fig.update_layout(template="plotly_dark")
    fig.update_xaxes(showgrid=False, showticklabels=False, zeroline=False)
    fig.update_yaxes(showgrid=False, showticklabels=False, zeroline=False)

    return fig


mock_header = html.Div(className='row', style={"display": "flex", "align-items": "center", "margin-bottom": "0px"},
                       children=[
                        

                           
                            html.Div(className='col-md-6', style={"text-align": "left"}, children=[
                            html.Img(
                                src="/assets/comcast_Business.PNG",  
                                
                                style={
                                    "height": "60px",  
                                    "width": "auto",   
                                    "margin": "0",
                                    "padding": "0",
                                    "margin-left": "4px"  
                
                                }
                            )]),
                            html.Div([ 
                            html.H1("ASK ANALYTICS", style={
                                            "display": "inline-block",
                                            "margin-left": "100px",
                                            "vertical-align": "middle",
                                            "margin": "0",
                                            "padding": "0"
                                            
                                        })],style={"display": "flex", "align-items": "center", "margin-left":"20px"})
                                    
                                                        
                       ])

# Chart Tab Content defined below
tab_chart_placeholder = html.Div(
    id="chart-tab-placeholder",
    style={"display": "none"},
    children=[
        dmc.CardSection(
            dmc.Group(
                children=[
                    dmc.Select(
                        label="Select Chart Type",
                        placeholder="Recommended Chart",
                        id="chart-list",
                        value="Recommended Chart",
                        data=[
                            "Recommended Chart",
                            "Bar Chart",
                            "Line Chart",
                            "Pie Chart",
                            "Scatter Plot",
                            "GroupedBar Chart",
                            "GroupedArea Chart",
                            "StackedBar Chart",
                            "Waterfall Chart"
                        ],
                        style={"width": 200, "marginBottom": 10},
                    ),
                    dmc.Group(
                        [
                            dmc.ActionIcon(
                                DashIconify(icon="zondicons:add-outline"),
                                color="gray",
                                variant="transparent",
                                id="save-graph",
                            ),
                            dmc.ActionIcon(
                                DashIconify(icon="material-symbols:edit"),
                                color="gray",
                                variant="transparent",
                                id="edit-graph",
                            ),
                            dmc.ActionIcon(
                                DashIconify(icon="game-icons:magic-hat"),
                                color="gray",
                                variant="transparent",
                                id="suggest-more",
                            ),
                        ],
                        spacing=1,
                    ),
                ],
                position="apart",
            ),
            withBorder=True,
            inheritPadding=True,
            py="7",
        ),
        dcc.Loading(
            id="loading-spinner-chart",
            type="dot",
            
            fullscreen=False,
            children=[
                dcc.Graph(
                    id="graph-placeholder",
                    figure={},  # Replace with actual chart figure
                ),
            ],
        ),
        # Add a Div to display the table names
        html.Div(id="table-names-placeholder", style={"marginTop": "20px"})
    ],
)

# Chart code Content defined below
tab_code_placeholder = html.Div(id="code-tab-placeholder", style={"display": "none"},
                                children=[
                                    dmc.CardSection(
                                        dmc.Group(
                                            children=[
                                                
                                            ],
                                            # position="apart",
                                        ),
                                        withBorder=True,
                                        inheritPadding=True,
                                        py="7",
                                    ),
                                        dmc.Group(
                                            
                                            
                                                
                                            
                                            dmc.Stack(
                                            children=[
                                                dmc.Title("Parameters", order=3),
                                                dmc.Code(
                                                        #children="""SQL Code for generating relevant output.""",
                                                        children=""" """,
                                                        id="code-placeholder-sql",
                                                        block=True,
                                                        bg="white",
                                                    ),
                                                dmc.Title("SQL Query", order=3),
                                                dmc.Code(
                                                        children=""" """,
                                                        id="code-placeholder",
                                                        block=True,
                                                        bg="white",
                                                ),
                                                dcc.Clipboard(target_id="code-placeholder"),
                                                html.Button(
                                                    id="copy-button",
                                                    n_clicks=0,
                                                    style={
                                                        "backgroundColor": "white",
                                                        "color": "white",
                                                        "border": "none",
                                                        "position": "absolute",  # Make button position absolute
                                                        "top": "10px",  # Distance from the top
                                                        "right": "10px",  # Distance from the right
                                                        "zIndex": "1",  # Ensure it stays above other elements
                                                    },
                                                ),
                                                dmc.ActionIcon(
                                                    DashIconify(icon="carbon:overflow-menu-horizontal"),
                                                    color="gray",
                                                    variant="transparent",
                                                ),
                                               

                                            ],

                                        ),
                                            
                                            
                                        
                                        ),
                                    
                                    
                                ], )

# Chart Table Content defined below
tab_table_placeholder = html.Div(id="table-tab-placeholder", style={"display": "none"},
                                 children=[
                                     dcc.Download(id='download-dataframe'),
                                     html.Div(
                                        children=[

                                     html.Button(
                                         id='download-button',
                                         children='Download CSV',
                                         style={
                                             'background-color': 'rgb(80, 171, 221)',
                                             'color': 'white',
                                             'padding': '9px 7px',
                                             'text-align': 'center',
                                             'cursor': 'pointer',
                                             'border-radius': '5px',
                                             'display': 'inline-block',
                                             #'align-items': 'center',
                                             #'justify-content': 'center',
                                             'margin-top': '14px',
                                             'margin-bottom': '14px',
                                             #'float': 'right',
                                         }
                                     ),
                                        ],
                                        style={
                                            'display': 'flex',
                                            'justify-content': 'flex-end',  # Align button to the right
                                            'width': '100%',
                                        }
                                     ),
                                     dash_table.DataTable(
                                         data=pd.DataFrame().to_dict(
                                             "records"
                                         ),
                                         page_size=10,
                                         style_table={
                                             "overflowX": "auto",
                                             "color": "black"
                                         },
                                         style_header={'font-weight': 'bold', 'font-size': '16px',
                                                       'background-color': 'rgb(39, 112, 193)', 'color': 'white',
                                                       'text-align': 'center',
                                                       'text-transform': 'uppercase'
                                                       },
                                        style_cell={
                                         'textAlign': 'center'  # This will center the table elements
                                                     },
                                         sort_action="native",
                                         id="table-placeholder",
                                        # columns = [{'name': col, 'id': col} for col in data.columns],
                                       
                                         
                                     ),
                                    
                                 ], )


def create_navbar(active_tab):
    def nav_item(label, icon, tab_value):
        return html.Div(
            className="col-md-auto",
            children=[
                dmc.Button(
                    children=[
                        DashIconify(icon=icon, width=20, color="white"),
                        dmc.Text(label, style={
                            "margin-left": "4px",
                            "font-size": "22px",
                            "color": "white"
                        }),
                    ],
                    variant="subtle",
                    style={
                        "margin-right": "20px",
                        "border-bottom": "3px solid" + (" white" if active_tab == tab_value else " transparent"),
                        "padding": "0 10px",
                        "background": "transparent",
                    },
                    n_clicks=0,
                    id={"type": "nav-item", "index": tab_value}
                )
            ]
        )

    return html.Div(
        className="row",
        children=[
            html.Div(
                className="col-md-12",
                style={
                    "background": "#112F64",
                    "padding": "10px 1px",
                    "border-bottom": "1px solid #e9ecef",
                    'box-shadow': '0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24)',
                    "width": "100%",
                    "margin-top": "-14px",
                    "display": "flex",
                    "align-items": "center",
                    "margin-left": "4px",
                    'height' : '30px',
                    'border-radius' : '5px'
                },
                children=[
                    #nav_item("Playground", "tabler:message", "workspace"),
                    nav_item("Chat Interface", "carbon:data-table", "workspace"),
                    #nav_item("Data Dictionary", "carbon:dashboard", "dashboard"),
                    nav_item("Data Dictionary", "carbon:data-set", "dashboard"),
                ]
            )
        ]
    )



### Code for Tabs Area

# Define the tabs area (right side)
tabs_area = (
    # dmc.LoadingOverlay([
    dmc.Stack(
        [
            dcc.Tabs(
                id="tabs-output",
                value="tab-2",  # Default to Tabular Outputs
                children=[
                    dcc.Tab(
                        label="Visualization",
                        value='tab-1',
                        style=tab_style,
                        selected_style=tab_selected_style
                    ),
                    dcc.Tab(
                        label='Data Table',
                        value='tab-2',
                        style=tab_style,
                        selected_style=tab_selected_style
                    ),
                    # dcc.Tab(
                    #     label='Insights (Coming Soon)',
                    #     value='tab-3',
                    #     style=tab_style,
                    #     selected_style=tab_selected_style
                    # ),
                ],
                colors={
                    "border": "white",
                    "primary": "orange",
                    "background": "white"
                },

                style={

                    "border": "1px solid #ccc",
                    "border-top-left-radius": "12px", "border-top-right-radius": "12px",
                    'box-shadow': '0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24)',
                    'background-color': 'white',
                    "padding": "12px"}

            ),
            html.Div(
                id="tabs-content-output",
                style={
                    "padding": "10px",
                    "border": "1px solid #ccc",
                    "height": "518px",  # Adjusted to give more space
                    "overflowY": "auto",
                    "border-bottom-left-radius": "12px", "border-bottom-right-radius": "12px",
                    "margin-top": "-17px",
                    'box-shadow': '0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24)',
                    'background-color': 'white',
                    "backgroundColor": 'white',
                },
                children=[tab_chart_placeholder, tab_table_placeholder, tab_code_placeholder]
            ),
        ],
        # )]
    ))

conversation_area = dmc.Stack(
    [
        # Top bar with Conversations text and the chat add button
        html.Div(
            className='row',
            children=[
                html.Div(
                    className='col-md-6',
                    children=[
                        dmc.Text(
                            "Conversations",
                            style={
                                "font-size": "20px",
                                "font-weight": "bold",
                                "color": "#000000",
                                "margin-left": "3%",
                                "margin-top": "10px"
                            },
                        ),
                    ],
                ),
                html.Div(
                    className='col-md-6',
                    children=[
                        dmc.Button(
                            id="new-conversation-button",
                            leftIcon=DashIconify(
                                icon="material-symbols:refresh",
                                style={
                                    'display': 'inline-flex',
                                    'align-items': 'center',
                                    'justify-content': 'center',
                                    'width': '39px',
                                    'height': '39px',
                                    # 'border-radius': '50%',
                                    "fontSize": "30px",
                                    #'color': 'rgb(39, 112, 193)',
                                    # 'box-shadow': '0px 4px 10px rgba(0, 0, 0, 0.25)',
                                }
                            ),
                            style={
                                "background-color": "transparent",
                                "color": "#000000",
                                "position": "absolute",
                                "right": "10px",
                                "top": "50%",
                                "margin-top": "-12px",
                                "transform": "translateY(-60%)",
                                # 'box-shadow': '0px 4px 10px rgba(0, 0, 0, 0.25)'
                            }
                        ),
                    ],
                    style={"position": "relative"}
                ),
            ],
            style={
                "background-color": "rgb(209,243,253)",
                "border-top-left-radius": "12px",
                "border-top-right-radius": "12px",
                "height": "50px"
            }
        ),
        # Conversation area
        html.Div(
            id="conversation-wrapper",
            children=[
                dcc.Loading(
                    id="loading-spinner-conversation",
                    type="dot",
                    fullscreen=False,
                    children=[
                        dmc.Card(
                            children=[
                                dmc.Stack(
                                    id="current-conversation",
                                    style={
                                        "height": "400px",
                                        "overflowY": "scroll",
                                        "padding": "10px",
                                        # "backgroundColor": "#f7f7f7",
                                    },
                                    children=[
                                        html.Div(
                                            "",
                                            style={
                                                "background-color": "white",
                                                "padding": "0px"
                                            },
                                        ),
                                    ],
                                ),
                            ],
                            withBorder=True,
                            shadow="sm",
                            radius="md",
                            style={"margin-top": "-16px", "border-radius": "0px"}
                        ),
                    ],
                ),
            ],
        ),
        # Empty space after the conversation area
        dmc.Group(
            children=[
                html.Div(id='save-memory', style={'display': 'none'}),
                dcc.Store(id="memory-list", storage_type='session', data=''),
            ],
            style={"display": "flex", "marginTop": "10px", "marginRight": "1px"},
        ),
        html.Div([

            dmc.Button(
                id="faq-icon-button",
                leftIcon=DashIconify(icon="material-symbols:lab-profile",
                                     style={"fontSize": "33px",
                                            #'color': 'rgb(39, 112, 193)',
                                            # 'box-shadow': '0px 4px 10px rgba(0, 0, 0, 0.25)',
                                            }),
                style={"background-color": "transparent", "color": "#000000"}
            ),

            
            dcc.Input(
                id="prompt-input",
                placeholder="Ask any questions about email perf. and campaign sizing.",
                # value="",
                debounce=True,
                style={
                    "fontSize": "17px",
                    "padding": 10,
                    "flex-grow": "1",
                    "border": "1px solid transparent",
                    "margin-left": "-3%"
                },
            ),

            # html.Div(
            #     children=[

            #     html.Div(

                
            #     className='row',
                
                    
            # children=[
            #     html.Div(
            #         className='col-md-4',
            #         children=[
            #         dcc.Input(
            #             id="prompt-input",
            #             placeholder="Ask me anything on Email & Mktg Uni!",
            #             debounce=True,
            #             style={
            #                 "fontSize": "17px",
            #                 "padding": "10px",
            #                 "border": "1px solid transparent",
            #                 "border-radius": "5px",
            #                 "width": "100%",  # Ensure input takes full width of the parent
            #             },
            #         ),
            #     ],
            #     id="input-container",  # This is the container to align the popover with
            #     style={
            #         "position": "relative",  # Allow the popover to be positioned relative to the input
            #         #"width": "500px",  # You can adjust this as needed
            #         "display": "flex",
            #         "margin-left": "-7%",
            #     },
            #     )
            # ]
            #     )
            #     ]
                

            # ),
            dmc.Button(
                id="submit-button",
                leftIcon=DashIconify(
                    icon="material-symbols:arrow-circle-right-outline",
                    style={
                        'display': 'inline-flex',
                        'align-items': 'center',
                        'justify-content': 'center',
                        'width': '38px',
                        'height': '38px',
                        'border-radius': '50%',
                        "fontSize": "30px",
                        #'color': 'rgb(39, 112, 193)',
                        # 'box-shadow': '0px 4px 10px rgba(0, 0, 0, 0.25)',
                    }

                ),
                style={
                    "background-color": "transparent",
                    "color": "#000000",
                }
            ),
             # FAQ Popover
            # dbc.Popover(
            #     id="faq-popover",
            #     target="input-container",  # Target the input container instead of the input itself
            #     is_open=False,
                
            #     #placement="top",  # Place popover above the input field
            #     style={
            #         "position": "absolute",
            #         #"left": "0px",             # Align to the left side of the container
            #         #"right": 0, 
            #         "transform": "translateX(-95%)",
            #         "backgroundColor": "#f8f9fa",
            #         "border": "1px solid #dee2e6",
            #         "borderRadius": "8px",
            #         "overflowY": "scroll",
            #         "width": "260px",  # Match popover width to the input container
            #         #"maxWidth": "100%", 
            #         "bottom": "25px", 
            #         "box-sizing": "border-box",
            #         "white-space": "normal",
            #         "word-wrap": "break-word",  # Ensure long text wraps
            #         "zIndex": 1000,
            #     },
            #     children=[
            #         dbc.PopoverHeader(
            #             "Frequently Asked Questions",
            #             style={
            #                 "background-color": "rgb(209,243,253)",
            #                 "color": "black",
            #                 "height": "30px",
            #                 "padding-top": "9px",
            #                 "padding-left": "10px"
            #             }
            #         ),
            #         dbc.PopoverBody(
            #             html.Div([
            #                 html.Div(
            #                     faq,
            #                     id={'type': 'faq-item', 'index': idx},
            #                     n_clicks=0,
            #                     style={
            #                         "cursor": "pointer",
            #                         "padding": "5px",
            #                         "margin": "0",
            #                         "borderBottom": "none",  # Remove the border between questions
            #                         "backgroundColor": "transparent",
            #                         "width": "100%",
            #                     }
            #                 ) for idx, faq in enumerate(faq_questions)
            #             ]),
            #             style={"backgroundColor": "#f8f9fa", "padding": "0"},
            #         ),
            #     ],
            # ),

            dcc.Store(id="query-result"),
        ],
            style={"display": "flex", "background-color": "rgb(209,243,253)",
                   "border-bottom-left-radius": "12px", "border-bottom-right-radius": "12px",
                   "height": "50px", "margin-top": "-16px",
                   "align-items": "center",  # Vertically center the elements
                   "justify-content": "space-between",  # Space them evenly if needed
                   },
        ),
            
             #FAQ Popover
            dbc.Popover(
                id="faq-popover",
                target="faq-icon-button",
                #target="prompt-input",  # Target the input box directly
                is_open=False,
                placement="bottom",
                style={"backgroundColor": "#f8f9fa", "border": "1px solid #dee2e6", "borderRadius": "8px",
                                            'width': '33%'},
                # style={
                #     "backgroundColor": "#f8f9fa",
                #     "border": "1px solid #dee2e6",
                #     "borderRadius": "8px",
                #     "width": "100%",  # Set a fixed width for the pop-up
                #     "maxWidth": "100%",  # Ensure it doesn't exceed the max width
                #     "text-align": "left",
                #     "white-space": "normal",  # Allow text wrapping
                #     "word-wrap": "break-word",  # Ensure words are wrapped if too long
                # },
                children=[
                    dbc.PopoverHeader("Frequently Asked Questions",
                                    style={"background-color": "rgb(209,243,253)", "color": "#000000", "height": "30px",
                                            "padding-top": "9px","padding-left":"10px",
                                            }),
                    dbc.PopoverBody(
                        html.Div([
                            html.Div(
                                faq,
                                id={'type': 'faq-item', 'index': idx},
                                n_clicks=0,
                                style={
                                    "cursor": "pointer",
                                    "padding": "5px",
                                    "margin": "0",
                                    
                                    "borderBottom": "1px solid #ccc",
                                    "backgroundColor": "transparent"
                                }
                                # style={
                                #         "cursor": "pointer",
                                #         "padding": "10px",
                                #         "margin": "0",
                                #         #"borderBottom": "1px solid #ccc",
                                #         "borderBottom": "none",
                                #         "backgroundColor": "transparent",
                                #         "width": "100%",  # Ensure it takes full width of the pop-up
                                #         "white-space": "normal",  # Wraps the text
                                #         "word-wrap": "break-word",  # Break long words
                                #     }
                            ) for idx, faq in enumerate(faq_questions)
                        ]),
                        style={"backgroundColor": "#f8f9fa"}
                    ),
                ],
            ),
        dcc.Store(id='scroll-script'),
        dcc.Interval(id='scroll-interval', interval=500, n_intervals=0),
    ],
    style={"padding": "12px", "border": "1px solid rgb(204, 204, 204)", "border-radius": "16px",
           'box-shadow': '0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24)',
           'background-color': 'white',"margin-left": "4px"}
)

# Combine conversation_area and tabs_area into the workspace
workspace_content = dmc.Grid(
    [
        dmc.Col(
            conversation_area,  # Left side: Conversation area
            span=4,  # This will occupy 4 out of 12 columns
        ),
        dmc.Col(
            tabs_area,  # Right side: Tabs area
            span=8,  # This will occupy 8 out of 12 columns
        ),
    ],
)

history_content = html.Div(
    "History Content Here",
    style={"padding": "20px"}
)

data_description_content = html.Div(
    "Data Description Content Here",
    style={"padding": "20px"}
)

dashboard_content = dmc.Stack(
    # dcc.Graph(figure=generate_table_from_excel(df))
)

app.layout = dmc.Stack(
    [
        dcc.Location(id='url', refresh=False),
        mock_header,  # Include the header at the top
        html.Div(id="navbar", children=create_navbar("workspace")),  # Dynamic navbar
        html.Div(id='tab-content', children=workspace_content),  # Placeholder for tab content
        html.Div("#ffffff", id="memory-flag", style={"display": "none"}),
        html.Div("", id="db-value", style={"display": "none"}),
        html.Div("", id="graph-parameters", style={"display": "none"}),
        html.Div(0, id="graph-flag", style={"display": "none"}),
        html.Div(0, id="reset-flag", style={"display": "none"}),
        html.Div([], id="conversation-buffer", style={"display": "none"}),
        dcc.Store(id="thumbs_status"),
        dcc.Store(id='faq-check-store', data={'faq_check': 0}),
        #html.Script(src="/assets/scroll-handler.js"),
        # dcc.Store(id='scroll-script'),
        # dcc.Interval(id='scroll-interval', interval=500, n_intervals=0),
    ], style={
        "background": '#fffafa',
        "height": "100vh",
        'font-family': 'sans-serif'}
)

# Function to calculate column widths based on content length
def calculate_column_widths(df):
    # Initialize list for storing widths
    column_widths = []
    
    # Loop through each column in the DataFrame
    for col in df.columns:
        # Calculate the maximum length of the values in each column (including header)
        max_data_len = max(df[col].astype(str).apply(len).max(), len(col))
        
        # Set width proportional to the length of the longest value
        column_widths.append(max_data_len * 1000)  # Factor to control the width
    
    return column_widths

# Function to generate lighter shades of a color
def lighten_color(rgb, factor=0.7):
    r, g, b = rgb
    return (int(r + (255 - r) * factor), int(g + (255 - g) * factor), int(b + (255 - b) * factor))

# Function to generate Dash DataTable
def generate_dash_table_from_excel(df):
    columns = [{'name': col.upper(), 'id': col} for col in df.columns if col != 'Data_Source']
    # Sort dataframe by 'Data Source' in descending order
    df = df.sort_values('Data_Source', ascending=False)
    # List of unique data sources
    unique_data_sources = df['Data_Source'].unique()
    base_color = (169, 169, 169)

    # Generate colors for each data source
    color_map = {source: 'rgb' + str(lighten_color(base_color, factor=0.7 + i*0.1)) for i, source in enumerate(unique_data_sources)}

    # Define conditional row styling based on 'Data Source'
    style_data_conditional = [
        {
            'if': {'filter_query': f'{{Data_Source}} = "{source}"'},
            'backgroundColor': color_map[source],
            'color': 'black'
        }
        for source in unique_data_sources
    ]

    # Create Dash DataTable with the specified formatting
    table = dash_table.DataTable(
        data=df.to_dict('records'),
        columns=columns,
        style_header={'fontWeight': 'bold', 'textAlign': 'left', 'backgroundColor': 'rgb(209, 243, 253)'},
        style_cell={
            'textAlign': 'left',
            'padding': '10px',
            'whiteSpace': 'normal',
            'height': 'auto',  # Adjust row height for long text
            'minWidth': '80px', 'width': 'auto', 'maxWidth': '180px',  # Dynamic width adjustment
            'overflow': 'hidden',  # Prevent overflowing text
            'textOverflow': 'ellipsis',  # Add ellipsis for long text
        },
        style_data={'backgroundColor': 'rgb(242, 242, 242)'},
        style_table={
            'height': '100%',  # Make table height 100% of available space
            'width': '100%',   # Make table width 100% of available space
            'minWidth': '100%'  # Ensure table stretches to full width
        },
        fixed_columns={'headers': True, 'data': 1},  # Fix first column and header
        column_selectable="single",  # Columns can be selected
        sort_action="native",  # Enable sorting
        style_data_conditional=style_data_conditional  # Apply conditional styling
    )

    return html.Div([
        dcc.Store(id='scroll-script'),  # Store component
        dcc.Interval(id='scroll-interval', interval=500, n_intervals=0),  # Interval component
        table
    ],id="data-dict", style={'overflowY': 'scroll', 'height': 'auto'})  # Overall div style
@app.callback(
    [Output('navbar', 'children'),
     Output('tab-content', 'children')],
    [Input({"type": "nav-item", "index": ALL}, 'n_clicks')]
)
@measure_runtime
def render_content(n_clicks):
    print ("This callback is triggered")
    ctx = callback_context
    if not ctx.triggered or all(click == 0 for click in n_clicks):
        print ("This if is triggered")
        return create_navbar("workspace"), workspace_content

    clicked_tab = ctx.triggered[0]['prop_id'].split('.')[0]
    tab_value = eval(clicked_tab)['index']
    print(tab_value)

    # Ensure the correct content and navbar state based on the selected tab
    if tab_value == 'dashboard':
        # return create_navbar('dashboard'), dashboard_content
        return create_navbar('dashboard'), generate_dash_table_from_excel(df_dd)
        
    elif tab_value == 'history':
        return create_navbar('history'), history_content
    elif tab_value == 'data-description':
        return create_navbar('data-description'), data_description_content
    else:
        return create_navbar('workspace'), workspace_content
    time.sleep(1)

# Callback to handle tab switching and content rendering
@callback(
    # Output("tabs-content-output", "children"),
    [Output('chart-tab-placeholder', 'style'),
     Output('table-tab-placeholder', 'style'),
     Output('code-tab-placeholder', 'style'), ],
    Input("tabs-output", "value"),
)
@measure_runtime
def render_tab_content(tab):
    if tab == "tab-1":
        return {'display': 'block'}, {'display': 'none'}, {'display': 'none'}
    elif tab == "tab-2":
        return {'display': 'none'}, {'display': 'block'}, {'display': 'none'}
    elif tab == "tab-3":
        return {'display': 'none'}, {'display': 'none'}, {'display': 'block'}


@app.callback(
    Output("dropdown-container", "style"),
    Input("icon-button", "n_clicks"),
    [State("dropdown-container", "style")]

)
@measure_runtime
def toggle_dropdown(n_clicks, current_style):
    if n_clicks % 2 == 1:  # Toggle the visibility on odd clicks
        return {"display": "block"}  # Show dropdown
    return {"display": "none"}  # Hide dropdown

@measure_runtime
def send_gpt_request(
        client,
        prompt,
        max_tokens=1000,
        temperature=0.1,
        top_p=1,
        max_retries=5, ):
    message_text = [{"role": "system", "content": prompt}]
    completion = client.chat.completions.create(
        # model="gpt-35-turbo-16k",
        model ='Azure-Open-AI-Deployment',
        messages=message_text,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None)

    return completion

@measure_runtime
def generate_response_with_LLM(history, user_input, main_prompt, few_shot_prompt, previous_response):
    assistant_name = "AI Assistant"
    response = "Server is down. Please wait a few minutes and try again"
    today = pd.Timestamp.today()
    current_date = today.date()
    today_day_of_week = today.day_name()
    dates = get_dynamic_dates()
    current_week = dates['current_week']
    previous_year = dates['previous_year']
    previous_week = dates['previous_week']
    previous_fiscal_month = dates['previous_fiscal_month']
    previous_quarter = dates['previous_fiscal_quarter']
    previous_half_year = dates['previous_half_year']
    print("_______------------------------------Day----------------",previous_half_year)
    
    few_shot_example = few_shot_prompt.invoke(
        {"input": (previous_response or "") + " " + (user_input or ""), "dialect": "SQLite", "top_k": 5}
    ).text
    # print("few show ", few_shot_example)
    prompt = (
        main_prompt[0]
        .format(
            history=history,
            few_shot_examp=few_shot_example,
            user_input=user_input,
            current_date = current_date,
            today_day_of_week=today_day_of_week,
            latest_data_date = current_week,
            previous_year = previous_year,
            previous_week = previous_week,
            previous_fiscal_month = previous_fiscal_month, 
            previous_quarter = previous_quarter, 
            previous_half_year = previous_half_year
        )
        .replace("<split>", "\n")
    )
    
    response_data = send_gpt_request(
        client,
        prompt,
        max_tokens=1000,
        temperature=0.1,
        top_p=1,
        max_retries=10,
    )
    response = response_data.choices[0].message.content
    history += f"<split>Human: {user_input}<split>{assistant_name}: {response}"
    last_response = f"<split>Human: {user_input}<split>{assistant_name}: {response}"
    return response, history, prompt, last_response


@app.callback(
    Output("faq-popover", "is_open", allow_duplicate=True),
    Input("faq-icon-button", "n_clicks"),
    [State("faq-popover", "is_open")],
    prevent_initial_call=True,
)
@measure_runtime
def toggle_popover(icon_clicks, is_open):
    if icon_clicks:
        return not is_open
    return is_open

@app.callback(
    Output("faq-popover", "is_open", allow_duplicate=True),
    Input({'type': 'faq-item', 'index': ALL}, 'n_clicks'),
    [State("faq-popover", "is_open")],
    prevent_initial_call=True,
)
@measure_runtime
def select_faq_and_close_popover(faq_clicks, is_open):
    ctx = callback_context
    if any(faq_clicks):
        print("Selecting FAQ triggered")
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        button_id_dict = json.loads(button_id)
        index = button_id_dict['index']
        prompt = faq_questions[index]
        print("Question Selected : ", prompt)
        return False
    return is_open

@app.callback(
    Output('table-names-placeholder', 'children'),
    Input("tabs-output", "value"),  # Or any other trigger related to the query
    State('sql-query-input', 'data')  # Assuming you have the SQL query stored in this input
)
@measure_runtime
def update_table_names(tab, session_data):
    print("Update table called************")
    if tab == "tab-1":
        session_data = json.loads(session_data)
        sql_query= session_data["sql"]
        print(f"Update table callbaclk, session_data {session_data} and sql_query {sql_query}")
        if sql_query:
            # Use your function to extract the table names from the SQL query
            table_names = get_sql_query_summary(sql_query)
            # Format the table names as a list or however you want to display them
            return html.Div(
                [
                    html.H5("Tables Used in the Query:"),
                    html.Ul([html.Li(table_name) for table_name in table_names])
                ]
            )
        return ""
    return ""


@app.callback(
    Output("code-placeholder", "children", allow_duplicate=True),
    Output("code-placeholder-sql", "children", allow_duplicate=True),
    Output("table-placeholder", "data", allow_duplicate=True),
    Output("query-result", "data", allow_duplicate=True),
    Output("conversation-buffer", "children", allow_duplicate=True),
    Output("save-memory", "children", allow_duplicate=True),
    Output("current-conversation", "children", allow_duplicate=True),
    Output("graph-placeholder", "figure", allow_duplicate=True),
    Output("prompt-input", "value", allow_duplicate=True),
    Input({'type': 'faq-item', 'index': ALL}, 'n_clicks'),
    # State("faq-popover", "is_open"),
    # State("faq-check-store", 'data'),
    State("conversation-buffer", "children"),
    State("current-conversation", "children"),
    State("memory-list", "data"),
    prevent_initial_call=True,
)
@measure_runtime
def process_faq_selection(faq_clicks, conversation_buffer, current_conversation, data):
    ctx = callback_context
    if any(faq_clicks):
        print("FAQ selection triggered")
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        button_id_dict = json.loads(button_id)
        index = button_id_dict['index']
        prompt = faq_questions[index]
        print("Processing FAQ prompt: ", prompt)
        
        current_conversation.append(
            dmc.Group(
                [
                    dmc.Space(),
                    dmc.Text("You", weight=700, color="#FB4E0B", style={"font-family": "Roboto"}),
                    dmc.Text(
                        prompt,
                        size="sm",
                        align="left",
                        style={
                            "color": "#373737",
                            "font-family": "Roboto",
                            "font-size": "14px",
                            "font-style": "normal",
                            "font-weight": "400",
                            "padding": "17px 28px",
                            "width": "1000px",
                            "background-color": "#f2f2f2",
                            "border-radius": "8px",
                        },
                    ),
                ],
                position="right",
            )
        )
        conversation_buffer.append(prompt)
        print("Conversation Buffer : ", conversation_buffer)
        embeddings = AzureOpenAIEmbeddings(model="AdaEmbedding", azure_endpoint = "https://genaiinitiativeopenai.openai.azure.com/")
        example_selector = SemanticSimilarityExampleSelector.from_examples(
            examples,
            embeddings,
            FAISS,
            k=5,
            input_keys=["input"],
        )
        system_prefix = ("""Here are some examples of user inputs and their corresponding SQL queries:""")
        few_shot_prompt = FewShotPromptTemplate(
            example_selector=example_selector,
            example_prompt=PromptTemplate.from_template(
                "User input: {input}\nSQL query: {query}"
            ),
            input_variables=["input", "dialect", "top_k"],
            prefix=system_prefix,
            suffix="",
        )
        if isinstance(data, list):
            # Join the list into a single string, assuming it's a list of strings
            data = " ".join(data)
        list_of_all_questions = [words for words in data.split("<split>") if words.startswith("Human:")]
        if len(list_of_all_questions) == 0:
            list_of_all_questions = ''
        else:
            list_of_all_questions = list_of_all_questions[-1]
        response, data, final_prompt, last_response = generate_response_with_LLM(data, prompt, main_prompt, few_shot_prompt, list_of_all_questions)
        print("Here after Generate Response With LLM")
        try:
            print("Inside TRY")
            if response == 'False_Input':
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = "Sorry! Currently, I'm only trained to answer queries related to Sales & Demand for SMB Customers. If you have any questions on this, I'd be happy to assist you!"
                df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking general knowledge questions. No need to run the sql functions") 
            elif response == 'Wrong_Input':
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. This operation is not allowed as of now.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking to insert or delete or update or drop a table. No need to run the sql functions")
            elif check_hello_response(response):
                print("Greeting Message")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. It might be due to invalid input query or insufficient data information. Please try modifying your input or provide additional details for better assistance.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': response }, index=[0]), query_failed_msg, False
                logger.debug("User is giving greetings. No need to run the sql functions")
            elif not is_valid_sql(data.split("AI Assistant:")[-1]) or response is None:
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. It might be due to invalid input query or insufficient data information. Please try modifying your input or provide additional details for better assistance.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': response }, index=[0]), query_failed_msg, False

                logger.debug("LLM is asking clarifying questions. No need to run the sql functions")
            else:
                print("*****************its valid SQL query")
                df, SQL_query = get_table_output(response, table_dict)
                print("Printing DF : ", df)
                print("Printing SQL_query : ", SQL_query)
                no_compute = False
                SQL_query = sqlparse.format(SQL_query, reindent=True, keyword_case="upper")
                print('--------=====df========---------', df, '&&', SQL_query)
        except Exception as e:
            print("Here in Exception")
            logger.error(f"{prompt} | {SQL_query} | {e}")
            df, SQL_query = pd.DataFrame(), None
        if 'Fiscal Month' in df.columns and 'Fiscal Year' in df.columns:
            df = df.drop(columns=['Fiscal Year'])
        elif 'Fiscal Year' in df.columns:
            df['Fiscal Year'] = df['Fiscal Year'].astype(str)
        df = df.apply(lambda col: col.astype(str) if col.dtype == "datetime64"or col.dtype == "object" else col)
        
        for col in df.columns:
            if 'Percentage' in col:
                if df[col].iloc[-1] == 0:
                    df.at[df.index[-1], col] = np.nan
        #unformatteddf = df.iloc[:-1].copy()
        def format_percentages(value):
            if value is None or not isinstance(value, (int, float)):
                return value
            return f"{value / 100:.1%}"
        def format_mrc(value):
            num = int(value)
            if num >= 1000000:
                return f"${num / 1000000:.1f}M"
            elif num >= 1000:
                return f"${num / 1000:.1f}k"
            return f"${num:,}"
        def format_sales(value):
            try:
                if value is None:
                    return "N/A" 
                numeric_value = float(value)
                return f"{int(numeric_value):,}"
            except ValueError:
                return value
        def format_leads(value):
            value= round(float(value))
            return f"{int(value):,}"
        
        def format_onedecimal(value):
            return round(value, 1)
        # Function to apply formatting based on column name
        def format_dataframe(df):
            for col in df.columns:
                if 'MRC' in col or 'ARPS' in col or 'Revenue' in col:
                    df[col] = df[col].apply(format_mrc)
                elif 'Percentage' in col or '%' in col:
                    df[col] = df[col].apply(format_percentages)
                elif 'Sales' in col:
                    df[col] = df[col].apply(format_sales)
                elif 'Leads' in col or 'Demand' in col or 'Lines' in col or 'Accounts' in col:
                    df[col]=df[col].apply(format_leads)
                elif 'Per' in col:
                    df[col]=df[col].apply(format_onedecimal)

                elif df[col].dtype in ['int64', 'float64']:
                    df[col]=df[col].apply(format_onedecimal)    
                else:
                    df[col] = df[col].apply(str)
            return df
        df = df.fillna('')
        print(df)
        df = format_dataframe(df)
        df.columns = df.columns.str.replace('_', ' ')
        df.columns = df.columns.map(lambda col: ' '.join(col.split()[:4]))
        session_data = {
            "dataframe": df.to_json(orient="split"),
            "sql": SQL_query,
            "user_input": prompt,
            "llm_response": response,
            "no_compute": no_compute
        }
        logger.info(f"{prompt} | {SQL_query}")
        if no_compute:
            print('Here as no_compute is : ', no_compute)
            chart = blank_fig()
            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            response,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )

            if SQL_query is not None:
                table_where_having= get_sql_query_summary(SQL_query)
            return (
                SQL_query or "",
                table_where_having or "",
                df.to_dict("records") if df is not None else [],
                json.dumps(session_data) if session_data else "{}",
                conversation_buffer or [],
                dcc.Store(id="memory-list", data=data),
                current_conversation or [],
                chart if chart else blank_fig(),
                "",
                #table_where_having or "",
                )
            

        elif SQL_query is not None:
            print('SQL Query is not NONE')
            solution_table = df.to_dict("records")
            solution_table_cols = list(df.columns)
            rows_or_cols_nl_temp2 = ""
            if df.shape[0] == 1 and df.shape[1] > 1:
                rows_or_cols_nl_temp2 = "column"
            elif df.shape[0] > 1 and df.shape[1] >= 1:
                rows_or_cols_nl_temp2 = "row"

            default_response_1 = "Data and visualizations have been successfully generated. Please refer to these for further details"

            try:
                chart = chart_output(df, prompt, "Recommended")
            except Exception as e:
                chart = blank_fig()

            print("Appending to Current Conversation ")
            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            default_response_1,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )
            print("#################", chart)
            print("*****************", SQL_query)
            df = convert_float_to_int(df)
            df[df.select_dtypes(include='int64').columns] = df.select_dtypes(include='int64').map(format_commas_int)
            df[df.select_dtypes(include='float64').columns] = df.select_dtypes(include='float64').map(format_commas_int)
            if SQL_query is not None:
                table_where_having= get_sql_query_summary(SQL_query)
            return(
                SQL_query or "",
                table_where_having or "",
                df.to_dict("records") if df is not None else [],
                json.dumps(session_data) if session_data else "{}",
                conversation_buffer or [],
                dcc.Store(id="memory-list", data=data),
                current_conversation or [],
                chart if chart else blank_fig(),
                "",
            )
        else:
            print("Here as SQL Query is None")
            chart = blank_fig()
            print("Appending to Current Conversation ")
            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            response,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )
        if SQL_query is not None:
            table_where_having= get_sql_query_summary(SQL_query)    
        return (
                SQL_query or "",
                table_where_having or "",
                df.to_dict("records") if df is not None else [],
                json.dumps(session_data) if session_data else "{}",
                conversation_buffer or [],
                dcc.Store(id="memory-list", data=data),
                current_conversation or [],
                chart if chart else blank_fig(),
                "",
                #table_where_having or "",
            )

    else:
        return no_update, no_update, no_update, no_update, no_update, no_update, no_update,no_update,no_update


@app.callback(
    Output("code-placeholder", "children", allow_duplicate=True),
    Output("code-placeholder-sql", "children", allow_duplicate=True),
    Output("table-placeholder", "data", allow_duplicate=True),
    Output("query-result", "data", allow_duplicate=True),
    Output("conversation-buffer", "children", allow_duplicate=True),
    Output("save-memory", "children", allow_duplicate=True),
    Output("current-conversation", "children", allow_duplicate=True),
    Output("graph-placeholder", "figure", allow_duplicate=True),
    Output("prompt-input", "value", allow_duplicate=True),
    #Output('table-names-placeholder', 'children'),
    Input("prompt-input", "n_submit"),
    Input("submit-button", "n_clicks"),
    State("prompt-input", "value"),
    # State("faq-check-store", "data"),
    State("conversation-buffer", "children"),
    State("current-conversation", "children"),
    State("memory-list", "data"),
    background=True,
    manager=long_callback_manager,
    prevent_initial_call=True,
)
@measure_runtime
def process_prompt_input(n_submit, n_clicks, prompt, conversation_buffer, current_conversation, data):
    if not prompt:
        print("Prompt is empty")
        raise PreventUpdate
    if n_submit is None and n_clicks is None:
        print("Nothing is submitted or clicked")
        raise PreventUpdate

    if prompt and (n_submit is not None or n_clicks is not None):
        print("************* Processing Non FAQ prompt : ", prompt)
        
        # faq_check_data['faq_check'] = 0
        start = time.time()
        current_conversation.append(
            dmc.Group(
                [
                    dmc.Space(),
                    dmc.Text("You", weight=700, color="#FB4E0B", style={"font-family": "Roboto"}),
                    dmc.Text(
                        prompt,
                        size="sm",
                        align="left",
                        style={
                            "color": "rgb(59,55,89)",
                            "font-family": "Roboto",
                            "font-size": "14px",
                            "font-style": "normal",
                            "font-weight": "400",
                            "padding": "17px 28px",
                            "width": "1000px",
                            "background-color": "#f2f2f2",
                            "border-radius": "8px",
                        },
                    ),
                ],
                position="right",
            )
        )
        conversation_buffer.append(prompt)
        print("Conversation Buffer : ", conversation_buffer)
        embeddings = AzureOpenAIEmbeddings(model="AdaEmbedding", azure_endpoint = "https://genaiinitiativeopenai.openai.azure.com/")
        # few_shot_prompt = few_shot_prompt[-3].format(
    #     previous_week = previous_week,
    #     previous_fiscal_month = previous_fiscal_month,
    # )
        print("-----------------------Few Shot Examples---------------------", examples[0])
        example_selector = SemanticSimilarityExampleSelector.from_examples(
            examples,
            embeddings,
            FAISS,
            k=5,
            input_keys=["input"],
        )

        system_prefix = ("""Here are some examples of user inputs and their corresponding SQL queries:""")
        few_shot_prompt = FewShotPromptTemplate(
            example_selector=example_selector,
            example_prompt=PromptTemplate.from_template(
                "User input: {input}\nSQL query: {query}"
            ),
            input_variables=["input", "dialect", "top_k"],
            prefix=system_prefix,
            suffix="",
        )
        if isinstance(data, list):
            # Join the list into a single string, assuming it's a list of strings
            data = " ".join(data)

        list_of_all_questions = [words for words in data.split("<split>") if words.startswith("Human:")]
        if len(list_of_all_questions) == 0:
            list_of_all_questions = ''
        else:
            list_of_all_questions = list_of_all_questions[-1]

        response, data, final_prompt, last_response = generate_response_with_LLM(data, prompt, main_prompt, few_shot_prompt, list_of_all_questions)
        print("Here after Generate Response With LLM")

        try:
            print("Inside TRY")
            if response == 'False_Input':
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = "Sorry! Currently, I'm only trained to answer queries related to Sales & Demand for SMB Customers. If you have any questions on this, I'd be happy to assist you!"
                df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking general knowledge questions. No need to run the sql functions") 
            elif response == 'Wrong_Input':
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. This operation is not allowed as of now.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking to insert or delete or update or drop a table. No need to run the sql functions")
            elif check_hello_response(response):
                print("Greeting Message")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. It might be due to invalid input query or insufficient data information. Please try modifying your input or provide additional details for better assistance.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': response }, index=[0]), query_failed_msg, False
                logger.debug("User is giving greetings. No need to run the sql functions")
            elif not is_valid_sql(data.split("AI Assistant:")[-1]) or response is None:
                print("Invalid SQL or Response is None")
                #df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. It might be due to invalid input query or insufficient data information. Please try modifying your input or provide additional details for better assistance.'
                df, SQL_query, no_compute = pd.DataFrame({'Messages': response }, index=[0]), query_failed_msg, False
               
                logger.debug("LLM is asking clarifying questions. No need to run the sql functions")
            else:
                print("*****************its valid SQL query")
                df, SQL_query = get_table_output(response, table_dict)
                print("Printing DF : ", df)
                print("Printing SQL_query : ", SQL_query)
                no_compute = False
                SQL_query = sqlparse.format(SQL_query, reindent=True, keyword_case="upper")
                print('--------=====df========---------', df, '&&', SQL_query)
        except Exception as e:
            print("Here in Exception")
            logger.error(f"{prompt} | {SQL_query} | {e}")
            df, SQL_query = pd.DataFrame(), None
        if 'Fiscal Month' in df.columns and 'Fiscal Year' in df.columns:
            df = df.drop(columns=['Fiscal Year'])
        elif 'Fiscal Year' in df.columns:
            df['Fiscal Year'] = df['Fiscal Year'].astype(str)
        print(df.info)
        df = df.apply(lambda col: col.astype(str) if col.dtype == "datetime64"or col.dtype == "object" else col)
        
        for col in df.columns:
            if 'Percentage' in col:
                if df[col].iloc[-1] == 0:
                    df.at[df.index[-1], col] = np.nan
        #unformatteddf = df.iloc[:-1].copy()
        def format_percentages(value):
            if value is None or not isinstance(value, (int, float)):
                return value
            return f"{value / 100:.1%}"
        def format_mrc(value):
            num = int(value)
            if num >= 1000000:
                return f"${num / 1000000:.1f}M"
            elif num >= 1000:
                return f"${num / 1000:.1f}k"
            return f"${num:,}"
        def format_sales(value):
            try:
                if value is None:
                    return "N/A" 
                numeric_value = float(value)
                return f"{int(numeric_value):,}"
            except ValueError:
                return value
        def format_leads(value):
            value= round(float(value))
            return f"{int(value):,}"
        
        def format_onedecimal(value):
            return round(value, 1)
        # Function to apply formatting based on column name
        def format_dataframe(df):
            for col in df.columns:
                if 'MRC' in col or 'ARPS' in col or 'Revenue' in col:
                    df[col] = df[col].apply(format_mrc)
                elif 'Percentage' in col or '%' in col:
                    df[col] = df[col].apply(format_percentages)
                elif 'Sales' in col:
                    df[col] = df[col].apply(format_sales)
                elif 'Leads' in col or 'Demand' in col or 'Lines' in col or 'Accounts' in col:
                    df[col]=df[col].apply(format_leads)
                elif 'Per' in col:
                    df[col]=df[col].apply(format_onedecimal)

                elif df[col].dtype in ['int64', 'float64']:
                    df[col]=df[col].apply(format_onedecimal)    
                else:
                    df[col] = df[col].apply(str)
            return df
        df = df.fillna('')
        print(df)
        df = format_dataframe(df)
        df.columns = df.columns.str.replace('_', ' ')
        df.columns = df.columns.map(lambda col: ' '.join(col.split()[:4]))
        session_data = {
            "dataframe": df.to_json(orient="split"),
            "sql": SQL_query,
            "user_input": prompt,
            "llm_response": response,
            "no_compute": no_compute
        }
        logger.info(f"{prompt} | {SQL_query}")
        if no_compute:
            print('Here as no_compute is : ', no_compute)
            chart = blank_fig()
            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            response,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )
            if SQL_query is not None:
                table_where_having= get_sql_query_summary(SQL_query)
            return (
                SQL_query,
                table_where_having or "",
                df.to_dict("records"),
                json.dumps(session_data),
                conversation_buffer,
                dcc.Store(id="memory-list", data=data),
                current_conversation,
                chart,
                "",
                #table_where_having or "",
            )

        elif SQL_query is not None:
            print('SQL Query is not NONE')
            solution_table = df.to_dict("records")
            solution_table_cols = list(df.columns)
            rows_or_cols_nl_temp2 = ""
            if df.shape[0] == 1 and df.shape[1] > 1:
                rows_or_cols_nl_temp2 = "column"
            elif df.shape[0] > 1 and df.shape[1] >= 1:
                rows_or_cols_nl_temp2 = "row"

            default_response_1 = "Data and visualizations have been successfully generated. Please refer to these for further details"

            try:
                print('--------------chart_prompt--------------', prompt)
                print('--------------chart_df--------------', df)
                chart = chart_output(df, prompt, "Recommended")

            except Exception as e:
                print('--------------chart_exception--------------', e)
                chart = blank_fig()

            print("Appending to Current Conversation ")
            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            default_response_1,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )
            print("After appending Current Conversation : ", current_conversation)
            print("At the end of elif block when SQL Query is not none, Conversation Buffer is : ", conversation_buffer)
            df = convert_float_to_int(df)
            df[df.select_dtypes(include='int64').columns] = df.select_dtypes(include='int64').map(format_commas_int)
            df[df.select_dtypes(include='float64').columns] = df.select_dtypes(include='float64').map(format_commas_int)
            if SQL_query is not None:
                table_where_having= get_sql_query_summary(SQL_query)
            return (
                SQL_query,
                table_where_having or "",
                df.to_dict("records"),
                json.dumps(session_data),
                conversation_buffer,
                dcc.Store(id="memory-list", data=data),
                current_conversation,
                chart,
                "",
                #table_where_having or "",
                )

        else:
            print("Here as SQL Query is None")
            chart = blank_fig()
            print("Appending to Current Conversation ")

            current_conversation.append(
                dmc.Group(
                    [
                        dmc.Space(),
                        dmc.Text(
                            "CB Chat Tool",
                            weight=700,
                            color="#004DC1",
                            style={"padding": "20px 0px 0px 0px", "font-family": "Roboto"},
                        ),
                        dmc.Text(
                            response,
                            size="sm",
                            align="left",
                            style={
                                "color": "#373737",
                                "font-family": "Roboto",
                                "font-size": "14px",
                                "font-style": "normal",
                                "font-weight": "400",
                                "padding": "17px 28px",
                                "width": "1000px",
                                "background-color": "#E8F0FF",
                                "border-radius": "8px",
                            },
                        ),
                    ],
                    position="left",
                )
            )
            print("After appending to Current Conversation : ", current_conversation)
            print("At the end of else block when SQL Query is none, Conversation Buffer is : ", conversation_buffer)
            if SQL_query is not None:
                table_where_having= get_sql_query_summary(SQL_query)
        return (
            SQL_query,
            table_where_having or "",
            df.to_dict("records"),
            json.dumps(session_data),
            conversation_buffer,
            dcc.Store(id="memory-list", data=data),
            current_conversation,
            chart,
            "",
            #table_where_having or "",
        )


@callback(
    Output("graph-placeholder", "figure", allow_duplicate=True),
    Input("chart-list", "value"),
    State("query-result", "data"),
    background=True,
    manager=long_callback_manager,
    prevent_initial_call=True,
)
@measure_runtime
def change_graphs(user_selection, session_data):
    if session_data is None:
        # Return a default figure if session_data is None
        return go.Figure()
    session_data = json.loads(session_data)
    df = pd.read_json(session_data["dataframe"], orient="split")
    user_input = session_data["user_input"]
    print("user Selection is:",user_selection)
    if user_selection=='Waterfall Chart':
        print("executing if-------")
        chart=create_waterfall_chart(df)
    else:
        print("executing else----------")
        chart = chart_output(df, user_input, user_selection)
    return chart


@callback(
    Output('download-dataframe', 'data'),
    Input('download-button', 'n_clicks'),
    State('table-placeholder', 'data'),
    prevent_initial_call=True
)
@measure_runtime
def generate_csv(n_clicks, table_data):
    print("generate_csv is called", table_data)
    if n_clicks:
        print("Download Button is Clicked")
        df = pd.DataFrame(table_data)
        print(df)
        print(type(df))
        return dcc.send_data_frame(df.to_csv, filename="download_data.csv", index=False)
    raise PreventUpdate


@app.callback(
    Output("current-conversation", "children", allow_duplicate=True),
    Output("memory-list", "data"),
    Output("conversation-buffer", "children", allow_duplicate=True),
    Output("graph-placeholder", "figure", allow_duplicate=True),  # Clear the chart
    Output("table-placeholder", "data", allow_duplicate=True),  # Clear the table
    Output("code-placeholder", "children", allow_duplicate=True),  # Clear the SQL/code area
    Output("code-placeholder-sql", "children", allow_duplicate=True),
    Input("new-conversation-button", "n_clicks"),
    prevent_initial_call=True
)
@measure_runtime
def start_new_conversation(n_clicks):
    if n_clicks is None:
        raise PreventUpdate  # Prevent the callback from running if the button hasn't been clicked

    # Proceed with the logic if the button has been clicked
    print("********* New Conversation Button Clicked *********")
    initial_message = [
        html.Div(
            "",
            style={
                "padding": "10px",
                "border-radius": "5px",
                "margin-bottom": "10px",
                "fontSize": "20px",
            },
        )
    ]
    empty_figure = {}  # or use your preferred way to represent an empty chart
    empty_table = []  # or use your preferred way to represent an empty table
    empty_code = " "
    return initial_message, [], [], empty_figure, empty_table, empty_code,empty_code  # Return an empty buffer to fully reset the context


# Apply the decorator to the functions you want to measure
# render_content_runtime = measure_runtime(render_content)
# print(f"render_content_runtime: {render_content_runtime}")
# render_tab_content_runtime = measure_runtime(render_tab_content)
# print(f"render_tab_content_runtime: {render_tab_content_runtime}")
# toggle_dropdown_runtime = measure_runtime(toggle_dropdown)
# print(f"toggle_dropdown_runtime: {toggle_dropdown_runtime}")
# send_gpt_request_runtime = measure_runtime(send_gpt_request)
# print(f"send_gpt_request_runtime: {send_gpt_request_runtime}")
# generate_response_with_LLM_runtime = measure_runtime(generate_response_with_LLM)
# print(f"generate_response_with_LLM_runtime: {generate_response_with_LLM_runtime}")
# toggle_popover_runtime = measure_runtime(toggle_popover)
# print(f"toggle_popover_runtime: {toggle_popover_runtime}")
# select_faq_and_close_popover_runtime = measure_runtime(select_faq_and_close_popover)
# print(f"select_faq_and_close_popover_runtime: {select_faq_and_close_popover_runtime}")
# update_table_names_runtime = measure_runtime(update_table_names)
# print(f"update_table_names_runtime: {update_table_names_runtime}")
# process_faq_selection_runtime = measure_runtime(process_faq_selection)
# print(f"process_faq_selection_runtime: {process_faq_selection_runtime}")
# process_prompt_input_runtime = measure_runtime(process_prompt_input)
# print(f"process_prompt_input_runtime: {process_prompt_input_runtime}")
# change_graphs_runtime = measure_runtime(change_graphs)
# print(f"change_graphs_runtime: {change_graphs_runtime}")
# generate_csv_runtime = measure_runtime(generate_csv)
# print(f"generate_csv_runtime: {generate_csv_runtime}")
# start_new_conversation_runtime = measure_runtime(start_new_conversation)
# print(f"start_new_conversation_runtime: {start_new_conversation_runtime}")
import re

last_df_records={}
data=[]
user_histories={}
server.secret_key = 'supersecretkey'
@server.route('/gpt-request', methods=['POST'])
def gpt_request():

    bata = request.json
    prompt = bata.get('prompt')
    user_id = bata.get('userId') 
    user_name= bata.get('userName')
    unique_id=bata.get('uniqueId')
    userMail=bata.get('userMail')
    global user_histories
    if user_id not in user_histories:
        user_histories[user_id]=[]
    if user_id not in last_df_records:
        last_df_records[user_id]=pd.DataFrame
    print(f"Received prompt: {prompt}")
    print(f"Received userId: {user_id}")
    print(f"Received userId: {user_name}")
    print(f"Received userId: {userMail}")

    parts = user_name.split(',')   
    if len(parts) > 1:
        second_part = parts[1].strip()
        short_name = second_part.split()[0]
    else:
        parts=user_name.split(' ')
        if len(parts) > 1:
            second_part = parts[1].strip()
            short_name = second_part.split()[0]
        else:
            short_name=user_name
    
    print(short_name)
    show_short_name=random.choices([True, False], weights=[1, 3])[0]
    if show_short_name:
        greetuser="Here you go"+", " + short_name +"!"
    else:
        greetuser="Here you go!"
    #defaults
    select_statement="None"
    llm_text_response="None"
    table_output="None"
    fin_prompt="None"
    
    add_message="None"

    if (prompt):
        def check_for_graph(input_text):
            lower_case_input = input_text.lower()
            for graph in graph_list:
                graph_name = graph.lower().replace(" chart", "")
                if graph_name in lower_case_input:
                    if any(word in lower_case_input for word in ["change", "show", "give", "convert", "see", "switch", "about"]):
                        return graph
            return None
        selected_chart = check_for_graph(prompt)
        global last_sql_query
        if(selected_chart):
            query_date=datetime.now().isoformat()
            cosmo_data = {
                "id": unique_id,
                "query_time":query_date,
                "name": user_name,
                "Input": prompt,
                "output_query": "None",
                "text_response":"Chart has been changed successfully",
                "table_output":'None',
                "additional_message":"None",
                "final_prompt":"None"
            
            }
        
            url = 'https://teams-conversational-bi.documents.azure.com:443/'
            key = 'Vg0XJXMKqqT2L8fCXTHn5pAfFAFTj7VoUUaTMQrGCOzNvWcy5P7eYObwnnVgZOFRKAJZok35PQJmACDbgQMJiA=='
            database_name = 'TablesDB'
            container_name = 'gm_teams_applog'
            cosmoclient = CosmosClient(url, credential=key)
            database = cosmoclient.get_database_client(database_name)
            container = database.get_container_client(container_name)
            chart, x = chart_output_for_api(last_df_records[user_id], prompt, "Recommended")
            chart.update_layout(margin=dict(l=0, r=0, t=0, b=0))
            img_bytes = chart.to_image(format="png")
            img_base64 = base64.b64encode(img_bytes).decode('utf-8')
            
            adaptive_card_chart = {
                "type": "AdaptiveCard",
                "body": [
                    {
                        "type": "Image",
                        "url": f"data:image/png;base64,{img_base64}",
                        "size": "Stretch",
                        "maxWidth": "1000px",  # Increase width
                        "maxHeight": "100px"
                        
                    }
                ],
                "version": "1.2"
            }
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": adaptive_card_chart, "message": greetuser})

        embeddings = AzureOpenAIEmbeddings(model="AdaEmbedding", azure_endpoint = "https://genaiinitiativeopenai.openai.azure.com/")
        example_selector = SemanticSimilarityExampleSelector.from_examples(
            examples,
            embeddings,
            FAISS,                  
            k=5,
            input_keys=["input"],
        )
        system_prefix = ("""Here are some examples of user inputs and their corresponding SQL queries:""")
        few_shot_prompt = FewShotPromptTemplate(
            example_selector=example_selector,
            example_prompt=PromptTemplate.from_template(
                "User input: {input}\nSQL query: {query}"
            ),
            input_variables=["input", "dialect", "top_k"],
            prefix=system_prefix,
            suffix="",
        )
        #global data
        if isinstance(user_histories[user_id], list):
            data = " ".join(user_histories[user_id])
        list_of_all_questions = [words for words in data.split("<split>") if words.startswith("Human:")]
        list_of_all_questions = list_of_all_questions[-1] if list_of_all_questions else ''
        
        response, data, final_prompt, last_response = generate_response_with_LLM(data, prompt, main_prompt, few_shot_prompt, list_of_all_questions)
        print(len(user_histories[user_id]))
        
        
        user_histories[user_id].append(last_response)
        if(len(user_histories[user_id])>5):
            user_histories[user_id].pop(0)
        print("----------this is bots main prompt and history-------------------")
        print(len(data))
        print("--------------------------Data----------------------")
        print(data)
        print(prompt)
        select_index = last_response.upper().find('SELECT')

        if select_index != -1:
            select_statement = last_response[select_index:].strip()
        print(select_statement)
        
        
        print(user_id)
        print("--------------------------User History----------------------")
        print(user_histories)
        print(len(user_histories[user_id]))
        query_date=datetime.now().isoformat()
        cosmo_data = {
            "id": unique_id,
            "query_time":query_date,
            "name": user_name,
            "Input": prompt,
            "output_query": select_statement,
            "text_response":llm_text_response,
            "table_output":table_output,
            "additional_message":add_message,
            "final_prompt":final_prompt
        
        }
        
        url = 'https://teams-conversational-bi.documents.azure.com:443/'
        key = 'Vg0XJXMKqqT2L8fCXTHn5pAfFAFTj7VoUUaTMQrGCOzNvWcy5P7eYObwnnVgZOFRKAJZok35PQJmACDbgQMJiA=='
        database_name = 'TablesDB'
        container_name = 'gm_teams_applog'
        cosmoclient = CosmosClient(url, credential=key)
        database = cosmoclient.get_database_client(database_name)
        container = database.get_container_client(container_name)
        # dummy_json = json.dumps(cosmo_data)
        # # container.upsert_item(json.loads(dummy_json))


        try:
            if response == 'False_Input':
                print("Invalid SQL or Response is None")
                df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = "Sorry! Currently, I'm only trained to answer queries related to Sales & Demand for SMB Customers. If you have any questions on this, I'd be happy to assist you!"
                # df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking general knowledge questions. No need to run the sql functions") 
                
                cosmo_data["text_response"]=query_failed_msg
                dummy_json = json.dumps(cosmo_data)
                # container.upsert_item(json.loads(dummy_json))
                return jsonify({"response": query_failed_msg, "message": ""})
            elif response == 'Wrong_Input':
                print("Invalid SQL or Response is None")
                df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = "I'm sorry, but we are unable to generate an SQL query for this input. Operations such as INSERT, CREATE, DELETE, and UPDATE are not supported at this time. If you have any other questions related to sales or demand of our telecom products, I'd be happy to assist you!"
                # df, SQL_query, no_compute = pd.DataFrame({'Messages': query_failed_msg }, index=[0]), response, False
                logger.debug("LLM is asking to insert or delete or update or drop a table. No need to run the sql functions")
                cosmo_data["text_response"]=query_failed_msg
                dummy_json = json.dumps(cosmo_data)
                # container.upsert_item(json.loads(dummy_json))
                return jsonify({"response": query_failed_msg, "message": ""})
            elif check_hello_response(response):
                print("Greeting Message")
                df, SQL_query, no_compute = pd.DataFrame(), None, True
                query_failed_msg = 'Sorry! Currently, we are unable to generate an SQL query for this input. It might be due to invalid input query or insufficient data information. Please try modifying your input or provide additional details for better assistance.'
                # df, SQL_query, no_compute = pd.DataFrame({'Messages': response }, index=[0]), query_failed_msg, False
                logger.debug("User is giving greetings. No need to run the sql functions")
                cosmo_data["text_response"]="Hello! How can I assist you today?"
                dummy_json = json.dumps(cosmo_data)
                # container.upsert_item(json.loads(dummy_json))
                return jsonify({"response": response, "message": ""})
            elif not is_valid_sql(data.split("AI Assistant:")[-1]) or response is None:

                df, SQL_query, no_compute = pd.DataFrame(), None, True
                # response_data = send_gpt_request(
                #                                 client,
                #                                 final_prompt,
                #                                 max_tokens=1000,
                #                                 temperature=0.1,
                #                                 top_p=1,
                #                                 max_retries=10,
                #                                         )
                # response = response_data.choices[0].message.content
                if "SELECT" in response:
                    response="Sorry! I am not able to answer this at the moment"
                cosmo_data["text_response"]=response
                dummy_json = json.dumps(cosmo_data)
                # container.upsert_item(json.loads(dummy_json))
                return jsonify({"response": response, "message": ""})
        
                logger.debug("LLM is asking clarifying questions. No need to run the sql functions")
            else:
                df, SQL_query = get_table_output(response, table_dict)
                no_compute = False
                SQL_query = sqlparse.format(SQL_query, reindent=True, keyword_case="upper")
                sql_prompt = f"""
                    Analyze the following SQL query and provide a Concise summary of one or two lines. Mention the Columns which are selected and the filters that are applied.
                    SQL Query: {SQL_query}
                    please consider the following examples as reference :
                    Sample SQL query 1: SELECT Fiscal_Year AS 'Fiscal Year', Fiscal_Month AS 'Fiscal Month',
                                        SUM(ROUND(Total_Sales, 1)) AS 'BI Sales'
                                    FROM demand_sales
                                    WHERE Fiscal_Year = 2024
                                    AND Bi_Ind = 1
                                    GROUP BY Fiscal_Year, Fiscal_Month
                                    ORDER BY Fiscal_Month DESC
                    sample output 1: The results show BI sales for year 2024.
                    Sample SQL query 2: SELECT Fiscal_Year AS 'Fiscal Year', Fiscal_Month AS 'Fiscal Month',
                                        ROUND(SUM(Cbm_Lines), 1) AS 'CBM Lines Sold'
                                    FROM demand_sales
                                    WHERE Fiscal_Month BETWEEN DATEADD(MONTH, -5, '2025-02-01') AND '2025-02-01'
                                    GROUP BY Fiscal_Year, Fiscal_Month
                                    ORDER BY Fiscal_Month DESC
                    sample output 1: The results show CBM lines sold between 2025-02-01 and 2024-09-01
                    Instructions: 1. Please only speak about relevent columns ignoring any date and time based columns and also ignore information about ordering,grouping, tables used and Bi_ind . Also make sure to add the time frame to which the data belong to without fail. 
                    2. If any filter column ends with '_Ind' it is an indicator, you can ignore it.
                    Summary:
                    """
                response_data = send_gpt_request(
                                                client,
                                                sql_prompt,
                                                max_tokens=1000,
                                                temperature=0.1,
                                                top_p=1,
                                                max_retries=10,
                                                        )
                dm = response_data.choices[0].message.content

                
                
        except Exception as e:
            #logger.error(f"{prompt} | {SQL_query} | {e}")
            df, SQL_query = pd.DataFrame(), None
            no_compute= True
        if 'Fiscal Month' in df.columns and 'Fiscal Year' in df.columns:
            df = df.drop(columns=['Fiscal Year'])
        elif 'Fiscal Year' in df.columns:
            df['Fiscal Year'] = df['Fiscal Year'].astype(str)
        session_data = {
            "dataframe": df.to_json(orient="split"),
            "sql": SQL_query,
            "user_input": prompt,
            "llm_response": response,
            "no_compute": no_compute
        }
        logger.info(f"{prompt} | {SQL_query}")
        
        
        # def add_totals_row(df):
        #     totals = df.select_dtypes(include='number').sum()
        #     totals_row = pd.DataFrame(totals).T
        #     df_with_totals = pd.concat([df, totals_row], ignore_index=True)
        #     return df_with_totals
        # if len(df)>1:
        #     df = add_totals_row(df)
        #print(df)
        print("Number of columns:", df.shape[1])
        unformatteddf = df.copy()
        for col in df.columns:
            if 'Percentage' in col:
                if df[col].iloc[-1] == 0:
                    df.at[df.index[-1], col] = np.nan
        #unformatteddf = df.iloc[:-1].copy()
        def format_percentages(value):
            if value is None or not isinstance(value, (int, float)):
                return value
            return f"{value / 100:.1%}"
        def format_mrc(value):
            num = value
            if num >= 1000000:
                return f"${num / 1000000:.1f}M"
            elif num >= 1000:
                return f"${num / 1000:.1f}k"
            elif num < 500:
                return f"${num:.1f}"
            return f"${num:,}"
        def format_numbers(value):
            if value == 0:
                return "0"
            if value > 500:
                return "{:,.0f}".format(round(value))
            else:
                return "{:,.1f}".format(round(value, 1))
        percentage_in_dm=False
        if 'Percentage' in dm or '%' in dm or 'percentage' in dm:
                percentage_in_dm=True
                df[df.columns[-1]] = df[df.columns[-1]].apply(format_percentages)
        def format_dataframe(df):
            for col in df.columns:
                if 'MRC' in col or 'ARPS' in col or 'Revenue' in col:
                    df[col] = df[col].apply(format_mrc)
                elif 'Percentage' in col or '%' in col and percentage_in_dm ==False:
                    df[col] = df[col].apply(format_percentages)
                elif df[col].dtype in ['int64', 'float64']:
                    df[col]=df[col].apply(format_numbers)    
                else:
                    df[col] = df[col].apply(str)
            return df
        if 'Fiscal Month' in df.columns:
            df['Fiscal Month'] = pd.to_datetime(df['Fiscal Month'])
            df['Fiscal Month'] = df['Fiscal Month'].dt.strftime('%b-%Y')
        def is_first_of_month(date_str):
            try:
                date = pd.to_datetime(date_str.split()[0], format='%Y-%m-%d')
                return date.day == 1
            except ValueError:
                return False

        
        def convert_date_format(date_str):
            date_part = date_str.split()[0]
            rest_part = " ".join(date_str.split()[1:])
            return pd.to_datetime(date_part).strftime('%b-%Y').lower() + " " + rest_part

        
        new_columns = []
        for col in df.columns:
            if is_first_of_month(col):
                new_columns.append(convert_date_format(col))
            else:
                new_columns.append(col)

        df.columns = new_columns
        df = df.fillna('')
        print(df)
        df = format_dataframe(df)
        df.columns = df.columns.str.replace('_', ' ')
        df.columns = df.columns.map(lambda col: ' '.join(col.split()[:4]))
        table_rows = []
        header_cells = [{"type": "Column", "items": [{"type": "TextBlock", "text": col, "weight": "bolder", "horizontalAlignment": "Center", "wrap": True, "color": "accent","size": "small" if len(df.columns) >= 4 else "default"}], "width": "stretch", "separator": True} for col in df.columns]
        table_rows.append({"type": "ColumnSet", "columns": header_cells, "separator": True})

        for index, row in df.iterrows():
            cells = [{"type": "Column", "items": [{"type": "TextBlock", "text": "" if pd.isna(row[col]) else str(row[col]), "horizontalAlignment": "Center", "wrap": True,"size": "small" if len(df.columns) >= 4 else "default"}], "width": "stretch", "separator": True} for col in df.columns]
            table_rows.append({"type": "ColumnSet", "columns": cells, "separator": True})

        adaptive_card_content = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.5",
            "body": table_rows
        }
        if(df.iloc[0,0]=='One of the column is not found in dataset'):
            cosmo_data["text_response"]="Sorry! I couldn't find that information"
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": "Sorry! I couldn't find that information", "message": ""})
        elif(df.iloc[0,0]=='Query might succeeded, Affected rows: 0'):
            cosmo_data["text_response"]="Sorry! I am not able to answer this at the moment"
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": "Sorry! I am not able to answer this at the moment", "message": ""})
        elif df.shape[0]==1:
            json_df = df.to_json(orient='columns')
            cosmo_data["table_output"]=json_df
            cosmo_data["additional_message"]=dm
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": adaptive_card_content, "message": greetuser, "additional_message": dm})
        last_df_records[user_id]=unformatteddf
        
        try:
            chart, x = chart_output_for_api(unformatteddf, prompt, "Recommended")
            # if "Division" in df.columns:
            #     print("@@@@@@@@@@##############$$$$$$$$$$%%%%%%")
            #     color_map = {
            #                     'Central': '#7dedb5',
            #                     'West': '#907be9',
            #                     'Northeast': '#135cd3',
                                
            #                 }
            #     chart.for_each_trace(lambda t: t.update(marker_color=color_map.get(t.name, 'gray')))
            creation_successful = True
        except Exception as e:
            print(f"Chart creation failed: {e}")
            creation_successful = False
        chart.update_layout(margin=dict(l=0, r=0, t=0, b=0))
        img_bytes = chart.to_image(format="png")
        img_base64 = base64.b64encode(img_bytes).decode('utf-8')
        
        adaptive_card_chart = {
            "type": "AdaptiveCard",
            "body": [
                {
                    "type": "Image",
                    "url": f"data:image/png;base64,{img_base64}",
                    "size": "Stretch",
                    "maxWidth": "1000px",  # Increase width
                    "maxHeight": "100px"
                    
                }
            ],
            "version": "1.2"
        }
        
        if(df.iloc[0,0]=='One of the column is not found in dataset'):
            cosmo_data["text_response"]="One of the column is not found in dataset"
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": "One of the column is not found in dataset", "message": ""})
        elif(df.iloc[0,0]=='Query might succeeded, Affected rows: 0'):
            cosmo_data["text_response"]='Query might succeeded, Affected rows: 0'
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": 'Query might succeeded, Affected rows: 0', "message": ""})
        elif x == True or  creation_successful == False:
            json_df = df.to_json(orient='columns')
            cosmo_data["table_output"]=json_df
            cosmo_data["additional_message"]=dm
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": adaptive_card_content, "message": greetuser, "additional_message": dm})
        else:
            json_df = df.to_json(orient='columns')
            cosmo_data["table_output"]=json_df
            cosmo_data["additional_message"]=dm
            dummy_json = json.dumps(cosmo_data)
            # container.upsert_item(json.loads(dummy_json))
            return jsonify({"response": [adaptive_card_content, adaptive_card_chart], "message": greetuser, "additional_message": dm})
        
if __name__ == '__main__':
    
    app.run_server()
