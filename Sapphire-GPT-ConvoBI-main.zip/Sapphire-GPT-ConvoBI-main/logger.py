import os
import logging
connection_string = "DefaultEndpointsProtocol=https;AccountName=genaiadlsstoreage;AccountKey=ooFRZHQmY++urw0fSecoxj/2GoNxq9BozxYwNK4WRfO6Cdc3vGczFG8eTahgBlWol5cI7NIaXD/J+AStPJysfw==;EndpointSuffix=core.windows.net"
container_name = "$logs"
blob_name = "CBMA_Convo_Logs.txt"


import logging
from azure.storage.blob import BlobServiceClient

class AzureBlobStorageHandler(logging.Handler):
    def __init__(self, connection_string, container_name, blob_name):
        super().__init__()
        self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        self.container_name = container_name
        self.blob_name = blob_name
        self.blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)

    def emit(self, record):
        log_entry = self.format(record) + '\n'
        try:
            # Try to read existing logs from the blob
            try:
                existing_logs = self.blob_client.download_blob().readall().decode('utf-8')
            except Exception:
                existing_logs = ""  # If the blob doesn't exist, start with empty

            # Combine existing logs with the new log entry
            combined_logs = existing_logs + log_entry

            # Upload the combined logs to Blob Storage
            self.blob_client.upload_blob(combined_logs, overwrite=True)
        except Exception as e:
            print(f"Failed to upload log to Blob Storage: {e}")

def logger(name):
    
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(module)s | %(funcName)s | %(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S")
    #handler = logging.StreamHandler()
    handler = AzureBlobStorageHandler(connection_string, container_name, blob_name)
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    return logger